# -*- coding: utf-8 -*-
"""
run_dic_V3.py

autor: Jorge Ramón Parra Michel

Orquestador principal para DIC_2D_V3 inspirado en ncorr.

Objetivos de V3
---------------
1. Centralizar TODOS los parámetros de entrada al inicio del script.
2. Mantener compatibilidad con ROI regular, calibración y salidas métricas.
3. Preparar el pipeline para un núcleo de correlación tipo NCorr
   (RG-DIC / IC-GN / cálculo de gradientes de desplazamiento con strain radius).
4. Permitir aceleración por GPU donde exista soporte real.

Notas de diseño
---------------
- El cálculo interno puede mantenerse en px para correlación y gradientes.
- Los desplazamientos pueden exportarse en mm al final usando mm_per_px.
- El strain se conserva adimensional; para visualización puede mostrarse en microstrain.
- Este archivo asume la existencia futura del paquete DIC_2D_V3.
"""

from __future__ import annotations

import logging
from pathlib import Path
from pprint import pformat

import numpy as np


import matplotlib
matplotlib.use("Qt5Agg")
import matplotlib.pyplot as plt
plt.ion()

# ============================================================
# 0) PARÁMETROS DE ENTRADA - EDITAR AQUÍ
# ============================================================

# ----------------------------
# Rutas y nombre del proyecto
# ----------------------------
PROJECT = {
    "name": "pw-0mil-p2-n14",
    "image_dir": r".\imagenes",
    "image_pattern": "pw-0mil-p2-n14_*.tif",
    "output_dir": r".\resultados_dic_v3",
}

# ----------------------------
# GPU / backend numérico
# ----------------------------
COMPUTE = {
    "use_gpu": True,
    "gpu_backend": "torch",      # "torch" | "none"
    "gpu_device": "auto",       # "auto" | "cuda" | "cpu"
    "gpu_for_correlation": False, # se activará cuando el núcleo V3 lo soporte realmente
    "gpu_for_visualization": True,
    "num_threads": 0,             # 0 -> automático
}

# ----------------------------
# Imágenes y calibración
# ----------------------------
IMAGING = {
    "apply_calibration": True,
    "interactive_calibration": True,
    "use_saved_calibration_if_available": True,
    "distortion_correction": True,
    "output_units": "mm",       # "px" | "mm"
    "strain_display_units": "microstrain",  # "strain" | "microstrain"
}

# ----------------------------
# ROI y malla de análisis
# ----------------------------
ROI = {
    "interactive": True,
    "type": "rectangular",      # futuro: "polygonal"
    "xmin": None,
    "xmax": None,
    "ymin": None,
    "ymax": None,
    "spacing_x": 15,
    "spacing_y": 15,
}

# ----------------------------
# Parámetros DIC estilo NCorr
# ----------------------------

DIC = {
    "subset_radius": 21,
    "subset_spacing": 15,
    "cutoff_diffnorm": 1e-6,
    "cutoff_iteration": 50,
    "step_analysis": True,
    "subset_truncation": True,
    "corrcoef_min": 0.50,
    "search_radius": 23,
    "mode": "incremental",
    "seed_strategy": "propagation",
    "use_predictor": True,
    "engine": "rgdic",
    "interpolation": "bicubic",
    "warp": "affine",
}


# ----------------------------
# Postproceso de desplazamiento
# ----------------------------
DISPLACEMENT = {
    "outlier_method": "corrcoef+median",   # libre para V3
    "median_threshold": 2.5,
    "spatial_smoothing": "gaussian",       # "none" | "gaussian" | "median"
    "smoothing_kernel": 3,
    "fill_missing": True,
    "fill_method": "griddata",             # "nearest" | "linear" | "cubic" | "griddata"
    "export_displacements_in_mm": True,
}

# ----------------------------
# Strain / dispgrad estilo NCorr
# ----------------------------
STRAIN = {
    "engine": "ncorr_dispgrad",
    "strain_radius": 7,
    "tensor": "infinitesimal",
    "compute_shear": True,
    "compute_principal": True,
    "exclude_boundary": True,
}

# ----------------------------
# Incertidumbre
# ----------------------------
UNCERTAINTY = {
    "enabled": True,
    "mode": "gum",              # "gum" | "none"
}

# ----------------------------
# Visualización / exportación
# ----------------------------
VIS = {
    "dpi": 180,
    "export_format": "png",
    "show_progress_correlation": True,
    "smooth_method": "bspline",
    "upsample_nx": 320,
    "upsample_ny": 320,
    "levels": 140,
    "quiver_skip": 6,
    "quiver_gain": 3.0,
    "show_dashboard": True,
    "show_field_maps": True,
    "show_strain_vs_frame": True,
    "show_strain_vs_dmax": True,
}

RUNTIME = {
    "selected_frame": 40,
    "min_valid_points_per_frame": 300,
    "trim_correlation_tail": True,
    "show_selected_frame_results": True,
}





# ============================================================
# 1) IMPORTS DEL PAQUETE V3
# ============================================================
from DIC_2D_V3.config import DICConfigV3
from DIC_2D_V3.project import DICProjectV3
from DIC_2D_V3.utils import setup_logging_v3
from DIC_2D_V3.image_loader import run_image_loader_v3
from DIC_2D_V3.calibration import run_calibration_v3
from DIC_2D_V3.roi_grid import run_grid_definition_v3
from DIC_2D_V3.correlation_engine import run_correlation_v3
from DIC_2D_V3.displacement import run_displacement_v3
from DIC_2D_V3.strain import run_strain_v3
from DIC_2D_V3.uncertainty import run_uncertainty_v3
from DIC_2D_V3.visualization import (
    plot_dashboard_v3,
    plot_quiver_v3,
    plot_field_map_v3,
    plot_strain_vs_frame_v3,
    plot_strain_vs_max_displacement_v3,
)

# ============================================================
# 2) UTILIDADES LOCALES
# ============================================================
def resolve_gpu():
    """Detecta GPU y devuelve metadatos de ejecución."""
    gpu = {
        "available": False,
        "backend": COMPUTE["gpu_backend"],
        "device": "cpu",
        "device_name": "CPU",
        "torch_cuda_ok": False,
    }

    if not COMPUTE["use_gpu"] or COMPUTE["gpu_backend"] != "torch":
        return gpu

    try:
        import torch
        gpu["torch_cuda_ok"] = torch.cuda.is_available()

        if COMPUTE["gpu_device"] == "cpu":
            gpu["device"] = "cpu"
        elif COMPUTE["gpu_device"] == "cuda":
            gpu["device"] = "cuda:0" if gpu["torch_cuda_ok"] else "cpu"
        else:
            gpu["device"] = "cuda:0" if gpu["torch_cuda_ok"] else "cpu"

        if "cuda" in gpu["device"]:
            gpu["available"] = True
            gpu["device_name"] = torch.cuda.get_device_name(0)
        return gpu
    except Exception:
        return gpu


def build_config() -> DICConfigV3:
    """Arma el objeto de configuración V3 con todos los parámetros del script."""
    cfg = DICConfigV3(
        project_name=PROJECT["name"],
        image_dir=PROJECT["image_dir"],
        image_pattern=PROJECT["image_pattern"],
        output_dir=PROJECT["output_dir"],
    )

    # Compute
    cfg.compute.use_gpu = COMPUTE["use_gpu"]
    cfg.compute.gpu_backend = COMPUTE["gpu_backend"]
    cfg.compute.gpu_device = COMPUTE["gpu_device"]
    cfg.compute.gpu_for_correlation = COMPUTE["gpu_for_correlation"]
    cfg.compute.gpu_for_visualization = COMPUTE["gpu_for_visualization"]
    cfg.compute.num_threads = COMPUTE["num_threads"]

    # Imaging
    cfg.imaging.apply_calibration = IMAGING["apply_calibration"]
    cfg.imaging.interactive_calibration = IMAGING["interactive_calibration"]
    cfg.imaging.use_saved_calibration_if_available = IMAGING["use_saved_calibration_if_available"]
    cfg.imaging.distortion_correction = IMAGING["distortion_correction"]
    cfg.imaging.output_units = IMAGING["output_units"]
    cfg.imaging.strain_display_units = IMAGING["strain_display_units"]

    # ROI
    cfg.roi.interactive = ROI["interactive"]
    cfg.roi.type = ROI["type"]
    cfg.roi.xmin = ROI["xmin"]
    cfg.roi.xmax = ROI["xmax"]
    cfg.roi.ymin = ROI["ymin"]
    cfg.roi.ymax = ROI["ymax"]
    cfg.roi.spacing_x = ROI["spacing_x"]
    cfg.roi.spacing_y = ROI["spacing_y"]

    # DIC / NCorr style
    cfg.dic.subset_radius = DIC["subset_radius"]
    cfg.dic.subset_size = 2 * DIC["subset_radius"] + 1
    cfg.dic.spacing = DIC["subset_spacing"]
    cfg.dic.cutoff_diffnorm = DIC["cutoff_diffnorm"]
    cfg.dic.cutoff_iteration = DIC["cutoff_iteration"]
    cfg.dic.step_analysis = DIC["step_analysis"]
    cfg.dic.subset_truncation = DIC["subset_truncation"]
    cfg.dic.corrcoef_min = DIC["corrcoef_min"]
    cfg.dic.search_radius = DIC["search_radius"]
    cfg.dic.mode = DIC["mode"]
    cfg.dic.seed_strategy = DIC["seed_strategy"]
    cfg.dic.use_predictor = DIC["use_predictor"]
    cfg.dic.engine = DIC["engine"]
    cfg.dic.interpolation = DIC["interpolation"]
    cfg.dic.warp = DIC["warp"]

    # Displacement
    cfg.displacement.outlier_method = DISPLACEMENT["outlier_method"]
    cfg.displacement.median_threshold = DISPLACEMENT["median_threshold"]
    cfg.displacement.spatial_smoothing = DISPLACEMENT["spatial_smoothing"]
    cfg.displacement.smoothing_kernel = DISPLACEMENT["smoothing_kernel"]
    cfg.displacement.fill_missing = DISPLACEMENT["fill_missing"]
    cfg.displacement.fill_method = DISPLACEMENT["fill_method"]
    cfg.displacement.export_displacements_in_mm = DISPLACEMENT["export_displacements_in_mm"]

    # Strain
    cfg.strain.engine = STRAIN["engine"]
    cfg.strain.strain_radius = STRAIN["strain_radius"]
    cfg.strain.tensor = STRAIN["tensor"]
    cfg.strain.compute_shear = STRAIN["compute_shear"]
    cfg.strain.compute_principal = STRAIN["compute_principal"]
    cfg.strain.exclude_boundary = STRAIN["exclude_boundary"]

    # Uncertainty
    cfg.uncertainty.enabled = UNCERTAINTY["enabled"]
    cfg.uncertainty.mode = UNCERTAINTY["mode"]

    # Visualization
    cfg.visualization.dpi = VIS["dpi"]
    cfg.visualization.export_format = VIS["export_format"]
    cfg.visualization.show_progress_correlation = VIS["show_progress_correlation"]
    cfg.visualization.smooth_method = VIS["smooth_method"]
    cfg.visualization.upsample_nx = VIS["upsample_nx"]
    cfg.visualization.upsample_ny = VIS["upsample_ny"]
    cfg.visualization.levels = VIS["levels"]
    cfg.visualization.quiver_skip = VIS["quiver_skip"]
    cfg.visualization.quiver_gain = VIS["quiver_gain"]
    cfg.visualization.show_dashboard = VIS["show_dashboard"]
    cfg.visualization.show_field_maps = VIS["show_field_maps"]
    cfg.visualization.show_strain_vs_frame = VIS["show_strain_vs_frame"]
    cfg.visualization.show_strain_vs_dmax = VIS["show_strain_vs_dmax"]

    return cfg


def print_run_header(logger: logging.Logger, cfg: DICConfigV3, gpu: dict) -> None:
    logger.info("==================== DIC_2D_V3 ====================")
    logger.info("Proyecto: %s", cfg.project_name)
    logger.info("GPU available=%s | device=%s | name=%s",
                gpu["available"], gpu["device"], gpu["device_name"])
    logger.info("Subset radius=%d | spacing=%d | strain radius=%d",
                cfg.dic.subset_radius, cfg.dic.spacing, cfg.strain.strain_radius)
    logger.info("Engine DIC=%s | Engine strain=%s | tensor=%s",
                cfg.dic.engine, cfg.strain.engine, cfg.strain.tensor)



def _trim_second_axis(arr, n_keep: int):
    if arr is None:
        return None
    arr = np.asarray(arr)
    if arr.ndim == 2:
        return arr[:, :n_keep]
    if arr.ndim >= 3:
        sl = [slice(None)] * arr.ndim
        sl[1] = slice(0, n_keep)
        return arr[tuple(sl)]
    return arr


def _summarize_and_trim_correlation(proj: DICProjectV3, logger: logging.Logger):
    if proj.corr_coeff is None or proj.corr_flags is None:
        raise RuntimeError("No existen corr_coeff/corr_flags en el proyecto.")

    cc = np.asarray(proj.corr_coeff, dtype=float)
    flags = np.asarray(proj.corr_flags)

    valid_counts = np.sum(flags == 1, axis=0)

    logger.info("Resumen de correlación:")
    for i in range(cc.shape[1]):
        valid = flags[:, i] == 1
        cc_mean = float(np.nanmean(cc[valid, i])) if np.any(valid) else 0.0
        logger.info(
            "Frame %d: cc=%.4f | válidos=%d/%d",
            i + 1,
            cc_mean,
            int(valid_counts[i]),
            cc.shape[0],
        )

    if not RUNTIME["trim_correlation_tail"]:
        return proj, valid_counts, cc.shape[1] - 1

    min_valid = int(RUNTIME["min_valid_points_per_frame"])
    usable = np.where(valid_counts >= min_valid)[0]

    if usable.size == 0:
        raise RuntimeError(
            f"La correlación colapsó completamente. Ningún frame alcanzó "
            f"{min_valid} puntos válidos."
        )

    last_good = int(usable[-1])
    n_total = cc.shape[1]
    n_keep = last_good + 1

    if n_keep < n_total:
        logger.warning(
            "Se recortan los frames %d..%d por colapso de correlación "
            "(mínimo requerido: %d válidos/frame).",
            n_keep,
            n_total - 1,
            min_valid,
        )

        proj.corr_u = _trim_second_axis(proj.corr_u, n_keep)
        proj.corr_v = _trim_second_axis(proj.corr_v, n_keep)
        proj.corr_coeff = _trim_second_axis(proj.corr_coeff, n_keep)
        proj.corr_flags = _trim_second_axis(proj.corr_flags, n_keep)
        if getattr(proj, "corr_p", None) is not None:
            proj.corr_p = _trim_second_axis(proj.corr_p, n_keep)

        valid_counts = valid_counts[:n_keep]

    return proj, valid_counts, last_good


def _show_selected_frame_results(proj: DICProjectV3, cfg: DICConfigV3, gpu: dict, logger: logging.Logger):
    if proj.disp_x is None or proj.strain_xx is None:
        logger.warning("No existen desplazamientos/strain para inspección por frame.")
        return

    total_frames = proj.disp_x.shape[1]
    frame = int(RUNTIME["selected_frame"])

    if total_frames <= 0:
        logger.warning("No hay frames procesados para visualizar.")
        return

    if frame < 0 or frame >= total_frames:
        logger.warning(
            "selected_frame=%d fuera de rango. Se ajusta al último frame disponible: %d",
            frame, total_frames - 1
        )
        frame = total_frames - 1

    image_index = frame + 1
    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Frame DIC seleccionado: {frame}")
    print(f"Imagen asociada: {image_index}")
    if getattr(proj, "image_files", None) and image_index < len(proj.image_files):
        print(f"Archivo: {proj.image_files[image_index]}")

    # Imagen original asociada
    fig, ax = plt.subplots(figsize=(6, 8))
    ax.imshow(proj.images[image_index], cmap="gray")
    ax.set_title(f"Imagen original asociada al frame {frame} (img {image_index})")
    ax.axis("off")
    plt.tight_layout()
    plt.show()

    # Máscara de validez
    if getattr(proj, "corr_flags", None) is not None:
        valid = proj.corr_flags[:, frame].astype(bool)

        fig, ax = plt.subplots(figsize=(6, 8))
        ax.imshow(proj.images[image_index], cmap="gray")
        ax.scatter(proj.grid_x[~valid], proj.grid_y[~valid], s=8, c="red", label="inválidos")
        ax.scatter(proj.grid_x[valid], proj.grid_y[valid], s=8, c="lime", label="válidos")
        ax.set_title(f"Validez de correlación — frame {frame} | {valid.sum()}/{len(valid)} válidos")
        ax.legend()
        ax.axis("off")
        plt.tight_layout()
        plt.show()

    plot_dashboard_v3(
        proj,
        frame=frame,
        smooth_method=cfg.visualization.smooth_method,
        upsample_nx=cfg.visualization.upsample_nx,
        upsample_ny=cfg.visualization.upsample_ny,
        levels=cfg.visualization.levels,
        device=gpu["device"],
        save_path=out_dir / f"dashboard_frame_{frame:03d}.{cfg.visualization.export_format}",
    )

    plot_quiver_v3(
        proj,
        frame=frame,
        skip=cfg.visualization.quiver_skip,
        quiver_gain=cfg.visualization.quiver_gain,
        smooth_vectors=True,
        smooth_method=cfg.visualization.smooth_method,
        upsample_nx=180,
        upsample_ny=180,
        device=gpu["device"],
        save_path=out_dir / f"quiver_frame_{frame:03d}.{cfg.visualization.export_format}",
    )

    plot_field_map_v3(
        proj,
        proj.strain_xx,
        frame,
        title=f"εxx — frame {frame}",
        smooth_method=cfg.visualization.smooth_method,
        device=gpu["device"],
        save_path=out_dir / f"strain_xx_frame_{frame:03d}.{cfg.visualization.export_format}",
    )

    plot_field_map_v3(
        proj,
        proj.strain_yy,
        frame,
        title=f"εyy — frame {frame}",
        smooth_method=cfg.visualization.smooth_method,
        device=gpu["device"],
        save_path=out_dir / f"strain_yy_frame_{frame:03d}.{cfg.visualization.export_format}",
    )

    plot_field_map_v3(
        proj,
        proj.strain_xy,
        frame,
        title=f"εxy — frame {frame}",
        smooth_method=cfg.visualization.smooth_method,
        device=gpu["device"],
        save_path=out_dir / f"strain_xy_frame_{frame:03d}.{cfg.visualization.export_format}",
    )


def _repair_bad_frames_temporal(project, valid_counts, min_valid_ratio=0.50):
    
    """
    Repara frames malos en disp_x_px / disp_y_px usando interpolación temporal
    entre frames vecinos buenos.

    Se usa después de run_displacement_v3() y antes de run_strain_v3().
    """
    n_points = int(project.num_points)
    valid_ratio = np.asarray(valid_counts, dtype=float) / float(n_points)

    bad_frames = np.where(valid_ratio < float(min_valid_ratio))[0].tolist()
    if not bad_frames:
        return project, []

    good_frames = np.where(valid_ratio >= float(min_valid_ratio))[0].tolist()
    if not good_frames:
        return project, bad_frames

    for field_name in ["disp_x_px", "disp_y_px"]:
        A = getattr(project, field_name, None)
        if A is None:
            continue

        A = np.asarray(A, dtype=float).copy()

        for k in bad_frames:
            left = [j for j in good_frames if j < k]
            right = [j for j in good_frames if j > k]

            if left and right:
                j0 = left[-1]
                j1 = right[0]
                alpha = (k - j0) / float(j1 - j0)
                A[:, k] = (1.0 - alpha) * A[:, j0] + alpha * A[:, j1]
            elif left:
                A[:, k] = A[:, left[-1]]
            elif right:
                A[:, k] = A[:, right[0]]

        setattr(project, field_name, A)

    # reconstruir magnitud en px
    disp_mag_px = np.hypot(project.disp_x_px, project.disp_y_px)

    # reconstruir versiones en mm
    mm_per_px = None
    if getattr(project, "calibration", None) is not None:
        mm_per_px = getattr(project.calibration, "mm_per_px", None)

    if mm_per_px is not None and np.isfinite(mm_per_px) and mm_per_px > 0:
        project.disp_x_mm = project.disp_x_px * float(mm_per_px)
        project.disp_y_mm = project.disp_y_px * float(mm_per_px)
        project.disp_mag_mm = disp_mag_px * float(mm_per_px)

    # publicar en unidades pedidas
    output_units = str(project.config.imaging.output_units).lower().strip()
    if output_units == "mm" and getattr(project, "disp_x_mm", None) is not None:
        project.disp_x = project.disp_x_mm
        project.disp_y = project.disp_y_mm
        project.disp_mag = project.disp_mag_mm
    else:
        project.disp_x = project.disp_x_px
        project.disp_y = project.disp_y_px
        project.disp_mag = disp_mag_px

    return project, bad_frames

# ============================================================
# 3) MAIN
# ============================================================
def main() -> DICProjectV3:
    logger = setup_logging_v3(logging.INFO)
    gpu = resolve_gpu()
    cfg = build_config()

    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print_run_header(logger, cfg, gpu)
    logger.info("Resumen de parámetros:\n%s", pformat({
        "PROJECT": PROJECT,
        "COMPUTE": COMPUTE,
        "IMAGING": IMAGING,
        "ROI": ROI,
        "DIC": DIC,
        "DISPLACEMENT": DISPLACEMENT,
        "STRAIN": STRAIN,
        "UNCERTAINTY": UNCERTAINTY,
        "VIS": VIS,
        "RUNTIME": RUNTIME,
    }, sort_dicts=False))

    # --------------------------------------------------------
    # 0) Crear proyecto
    # --------------------------------------------------------
    proj = DICProjectV3.new(cfg)

    # --------------------------------------------------------
    # 1) Cargar imágenes
    # --------------------------------------------------------
    proj = run_image_loader_v3(proj, show_preview=True)
    logger.info("Imágenes cargadas: %d | shape=%s", proj.num_images, proj.image_shape)

    # --------------------------------------------------------
    # 2) Calibración / corrección óptica
    # --------------------------------------------------------
    if cfg.imaging.apply_calibration:
        proj = run_calibration_v3(
            proj,
            interactive=cfg.imaging.interactive_calibration,
            use_saved=cfg.imaging.use_saved_calibration_if_available,
        )
        if hasattr(proj, "calibration") and hasattr(proj.calibration, "mm_per_px"):
            logger.info("mm/px = %.8f", float(proj.calibration.mm_per_px))

    # --------------------------------------------------------
    # 3) ROI + grilla reducida
    # --------------------------------------------------------
    proj = run_grid_definition_v3(
        proj,
        interactive=cfg.roi.interactive,
        programmatic_roi=None if cfg.roi.interactive else {
            "type": cfg.roi.type,
            "xmin": cfg.roi.xmin,
            "xmax": cfg.roi.xmax,
            "ymin": cfg.roi.ymin,
            "ymax": cfg.roi.ymax,
            "spacing_x": cfg.roi.spacing_x,
            "spacing_y": cfg.roi.spacing_y,
        },
    )
    logger.info("Grilla aceptada: %d puntos", proj.num_points)

    # --------------------------------------------------------
    # 4) Correlación
    # --------------------------------------------------------
    proj = run_correlation_v3(
        proj,
        show_progress=cfg.visualization.show_progress_correlation,
        device=gpu["device"],
    )

    proj, valid_counts, last_good = _summarize_and_trim_correlation(proj, logger)
    logger.info("Último frame utilizable tras recorte: %d", last_good)

    # --------------------------------------------------------
    # 5) Postproceso de desplazamiento
    # --------------------------------------------------------
    proj = run_displacement_v3(proj, show_summary=True)

    # Reparación temporal de frames anómalos antes de derivar strain
    proj, repaired_frames = _repair_bad_frames_temporal(
        proj,
        valid_counts=valid_counts,
        min_valid_ratio=0.50
    )
    if repaired_frames:
        logger.warning("Frames reparados temporalmente antes de strain: %s", repaired_frames)

    # --------------------------------------------------------
    # 6) Strain
    # --------------------------------------------------------
    proj = run_strain_v3(proj, show_summary=True)

    # --------------------------------------------------------
    # 7) Incertidumbre
    # --------------------------------------------------------
    if cfg.uncertainty.enabled:
        proj = run_uncertainty_v3(proj, show_summary=True)

    # --------------------------------------------------------
    # 8) Visualización global
    # --------------------------------------------------------
    last = proj.disp_x.shape[1] - 1
    #last= 45

    if cfg.visualization.show_dashboard:
        plot_dashboard_v3(
            proj,
            frame=last,
            smooth_method=cfg.visualization.smooth_method,
            upsample_nx=cfg.visualization.upsample_nx,
            upsample_ny=cfg.visualization.upsample_ny,
            levels=cfg.visualization.levels,
            device=gpu["device"],
            save_path=out_dir / f"dashboard.{cfg.visualization.export_format}",
        )

    plot_quiver_v3(
        proj,
        frame=last,
        skip=cfg.visualization.quiver_skip,
        quiver_gain=cfg.visualization.quiver_gain,
        smooth_vectors=True,
        smooth_method=cfg.visualization.smooth_method,
        upsample_nx=180,
        upsample_ny=180,
        device=gpu["device"],
        save_path=out_dir / f"quiver.{cfg.visualization.export_format}",
    )

    if cfg.visualization.show_strain_vs_frame:
        plot_strain_vs_frame_v3(
            proj,
            components=["exx", "eyy", "exy"],
            save_path=out_dir / f"strain_vs_frame.{cfg.visualization.export_format}",
        )

    if cfg.visualization.show_field_maps:
        plot_field_map_v3(
            proj, proj.strain_xx, last,
            title="εxx",
            smooth_method=cfg.visualization.smooth_method,
            device=gpu["device"],
            save_path=out_dir / f"strain_xx.{cfg.visualization.export_format}",
        )
        plot_field_map_v3(
            proj, proj.strain_yy, last,
            title="εyy",
            smooth_method=cfg.visualization.smooth_method,
            device=gpu["device"],
            save_path=out_dir / f"strain_yy.{cfg.visualization.export_format}",
        )
        plot_field_map_v3(
            proj, proj.strain_xy, last,
            title="εxy",
            smooth_method=cfg.visualization.smooth_method,
            device=gpu["device"],
            save_path=out_dir / f"strain_xy.{cfg.visualization.export_format}",
        )

    if cfg.visualization.show_strain_vs_dmax:
        plot_strain_vs_max_displacement_v3(
            proj,
            components=["exx", "eyy"],
            metric="mean",
            save_path=out_dir / f"strain_vs_dmax.{cfg.visualization.export_format}",
        )

    # --------------------------------------------------------
    # 9) Visualización del frame seleccionado
    # --------------------------------------------------------
    if bool(RUNTIME["show_selected_frame_results"]):
        _show_selected_frame_results(proj, cfg, gpu, logger)

    # --------------------------------------------------------
    # 10) Guardar proyecto
    # --------------------------------------------------------
    saved_path = proj.save()
    logger.info("Proyecto guardado: %s", saved_path)
    logger.info(proj.status_summary())

    return proj


if __name__ == "__main__":
    proj = main()
