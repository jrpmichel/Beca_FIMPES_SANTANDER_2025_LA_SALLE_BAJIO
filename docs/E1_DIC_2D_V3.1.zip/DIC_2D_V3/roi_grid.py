# -*- coding: utf-8 -*-
"""
DIC_2D_V3/roi_grid.py

Definición de ROI y generación de grilla reducida para DIC_2D_V3.

Características
---------------
- ROI interactiva rectangular sobre la imagen de referencia.
- ROI programática rectangular o poligonal.
- Generación de centros de subset sobre grilla regular.
- Respeta márgenes impuestos por subset_radius para evitar subsets fuera de imagen.
- Guarda ROI, spacing y metadatos de grilla dentro de DICProjectV3.
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Any, Dict, Optional, Tuple

import numpy as np
from matplotlib.path import Path as MplPath

from .project import DICProjectV3, ROIDataV3
from .utils import Timer

logger = logging.getLogger("dic2d.v3.roi_grid")


# =====================================================================
# Helpers ROI
# =====================================================================
def _image_shape(project: DICProjectV3) -> Tuple[int, int]:
    if project.images is None or len(project.images) == 0:
        raise RuntimeError("No hay imágenes cargadas para definir la ROI.")
    img = np.asarray(project.images[project.reference_index])
    if img.ndim != 2:
        raise ValueError("La imagen de referencia debe ser monocromática 2D.")
    h, w = img.shape
    return int(h), int(w)


def _subset_margin(project: DICProjectV3) -> int:
    r = int(getattr(project.config.dic, "subset_radius", 0))
    return max(r, 0)


def _clip_rect_to_image(xmin: float, xmax: float, ymin: float, ymax: float, w: int, h: int, margin: int) -> Tuple[float, float, float, float]:
    xmin = float(max(margin, min(xmin, w - 1 - margin)))
    xmax = float(max(margin, min(xmax, w - 1 - margin)))
    ymin = float(max(margin, min(ymin, h - 1 - margin)))
    ymax = float(max(margin, min(ymax, h - 1 - margin)))

    if xmax < xmin:
        xmin, xmax = xmax, xmin
    if ymax < ymin:
        ymin, ymax = ymax, ymin

    return xmin, xmax, ymin, ymax


def _validate_spacing(spacing_x: int, spacing_y: int) -> Tuple[int, int]:
    sx = int(spacing_x)
    sy = int(spacing_y)
    if sx <= 0 or sy <= 0:
        raise ValueError("spacing_x y spacing_y deben ser enteros positivos.")
    return sx, sy


# =====================================================================
# ROI interactiva
# =====================================================================
def _interactive_rect_roi(project: DICProjectV3) -> Dict[str, Any]:
    try:
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
    except Exception as exc:
        raise RuntimeError("matplotlib es necesario para ROI interactiva.") from exc

    img = np.asarray(project.images[project.reference_index])
    h, w = img.shape
    margin = _subset_margin(project)
    sx, sy = _validate_spacing(project.config.roi.spacing_x, project.config.roi.spacing_y)

    print("\n=== ROI interactiva DIC_2D_V3 ===")
    print("Seleccione dos esquinas opuestas de la ROI rectangular.")
    print(f"Se aplicará margen automático de subset_radius = {margin} px.")

    fig, ax = plt.subplots(figsize=(9, 7))
    ax.imshow(img, cmap="gray")
    ax.set_title("ROI rectangular: seleccione 2 esquinas")
    ax.axis("on")

    pts = plt.ginput(2, timeout=0)
    if len(pts) != 2:
        plt.close(fig)
        raise RuntimeError("Se requieren exactamente dos puntos para definir la ROI.")

    (x1, y1), (x2, y2) = pts
    xmin, xmax = sorted([x1, x2])
    ymin, ymax = sorted([y1, y2])
    xmin, xmax, ymin, ymax = _clip_rect_to_image(xmin, xmax, ymin, ymax, w, h, margin)

    # Retroalimentación visual final
    rect = Rectangle((xmin, ymin), xmax - xmin, ymax - ymin, fill=False, edgecolor="lime", linewidth=1.5)
    ax.add_patch(rect)
    ax.set_title(f"ROI aceptada: x=[{xmin:.1f},{xmax:.1f}] y=[{ymin:.1f},{ymax:.1f}] | spacing=({sx},{sy})")
    plt.show(block=False)
    plt.pause(0.6)
    plt.close(fig)

    return {
        "type": "rectangular",
        "xmin": float(xmin),
        "xmax": float(xmax),
        "ymin": float(ymin),
        "ymax": float(ymax),
        "spacing_x": sx,
        "spacing_y": sy,
    }


# =====================================================================
# Grilla
# =====================================================================
def _rect_grid_from_roi(project: DICProjectV3, roi: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray]:
    h, w = _image_shape(project)
    margin = _subset_margin(project)

    xmin, xmax, ymin, ymax = _clip_rect_to_image(
        roi["xmin"], roi["xmax"], roi["ymin"], roi["ymax"], w, h, margin
    )
    sx, sy = _validate_spacing(roi["spacing_x"], roi["spacing_y"])

    # Centros de subset dentro de la ROI, incluyendo extremos si caen en la rejilla.
    xs = np.arange(np.ceil(xmin), np.floor(xmax) + 1, sx, dtype=float)
    ys = np.arange(np.ceil(ymin), np.floor(ymax) + 1, sy, dtype=float)

    if xs.size < 2 or ys.size < 2:
        raise ValueError(
            "La ROI es demasiado pequeña para generar una grilla útil. "
            "Aumente la ROI o reduzca spacing_x/spacing_y."
        )

    X, Y = np.meshgrid(xs, ys)
    return X.ravel().astype(np.float32), Y.ravel().astype(np.float32)


def _polygon_grid_from_roi(project: DICProjectV3, roi: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray]:
    h, w = _image_shape(project)
    margin = _subset_margin(project)
    sx, sy = _validate_spacing(roi["spacing_x"], roi["spacing_y"])

    polygon = np.asarray(roi["polygon"], dtype=float)
    if polygon.ndim != 2 or polygon.shape[1] != 2 or polygon.shape[0] < 3:
        raise ValueError("La ROI poligonal requiere un arreglo Nx2 con al menos 3 vértices.")

    # Recorte básico a la imagen considerando margen
    polygon[:, 0] = np.clip(polygon[:, 0], margin, w - 1 - margin)
    polygon[:, 1] = np.clip(polygon[:, 1], margin, h - 1 - margin)

    xmin = float(np.min(polygon[:, 0]))
    xmax = float(np.max(polygon[:, 0]))
    ymin = float(np.min(polygon[:, 1]))
    ymax = float(np.max(polygon[:, 1]))

    xs = np.arange(np.ceil(xmin), np.floor(xmax) + 1, sx, dtype=float)
    ys = np.arange(np.ceil(ymin), np.floor(ymax) + 1, sy, dtype=float)
    if xs.size == 0 or ys.size == 0:
        raise ValueError("La ROI poligonal no produce nodos con el spacing solicitado.")

    X, Y = np.meshgrid(xs, ys)
    pts = np.column_stack([X.ravel(), Y.ravel()])
    mask = MplPath(polygon).contains_points(pts)
    pts = pts[mask]
    if pts.shape[0] < 4:
        raise ValueError("La ROI poligonal produce muy pocos nodos válidos.")

    return pts[:, 0].astype(np.float32), pts[:, 1].astype(np.float32)


def _store_roi_and_grid(project: DICProjectV3, roi: Dict[str, Any], gx: np.ndarray, gy: np.ndarray) -> None:
    project.roi = ROIDataV3(
        type=str(roi["type"]),
        xmin=None if roi.get("xmin") is None else float(roi.get("xmin")),
        xmax=None if roi.get("xmax") is None else float(roi.get("xmax")),
        ymin=None if roi.get("ymin") is None else float(roi.get("ymin")),
        ymax=None if roi.get("ymax") is None else float(roi.get("ymax")),
        polygon=None if roi.get("polygon") is None else np.asarray(roi.get("polygon"), dtype=float),
    )

    project.grid_x = np.asarray(gx, dtype=np.float32).ravel()
    project.grid_y = np.asarray(gy, dtype=np.float32).ravel()
    project.spacing_x = int(roi["spacing_x"])
    project.spacing_y = int(roi["spacing_y"])
    project.update_grid_metadata()

    project.extra["roi"] = {
        "type": project.roi.type,
        "xmin": project.roi.xmin,
        "xmax": project.roi.xmax,
        "ymin": project.roi.ymin,
        "ymax": project.roi.ymax,
        "spacing_x": project.spacing_x,
        "spacing_y": project.spacing_y,
        "subset_margin_px": _subset_margin(project),
    }
    if project.roi.polygon is not None:
        project.extra["roi"]["polygon"] = project.roi.polygon.tolist()


# =====================================================================
# Visualización de comprobación
# =====================================================================
def _show_grid_overlay(project: DICProjectV3, title: str = "ROI + grilla V3") -> None:
    try:
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle, Polygon
    except Exception:
        logger.warning("matplotlib no disponible; se omite visualización de ROI/grilla.")
        return

    img = np.asarray(project.images[project.reference_index])
    gx = np.asarray(project.grid_x)
    gy = np.asarray(project.grid_y)

    fig, ax = plt.subplots(figsize=(9, 7))
    ax.imshow(img, cmap="gray")

    if project.roi.type == "rectangular" and project.roi.xmin is not None:
        rect = Rectangle(
            (project.roi.xmin, project.roi.ymin),
            project.roi.xmax - project.roi.xmin,
            project.roi.ymax - project.roi.ymin,
            fill=False,
            edgecolor="lime",
            linewidth=1.5,
        )
        ax.add_patch(rect)
    elif project.roi.type == "polygonal" and project.roi.polygon is not None:
        poly = Polygon(project.roi.polygon, closed=True, fill=False, edgecolor="lime", linewidth=1.5)
        ax.add_patch(poly)

    ax.scatter(gx, gy, s=10, c="red", edgecolors="none")
    ax.set_title(title)
    ax.set_aspect("equal")
    ax.invert_yaxis()
    ax.axis("on")
    plt.tight_layout()
    plt.show(block=False)
    plt.pause(0.6)
    plt.close(fig)


# =====================================================================
# API pública
# =====================================================================
def run_grid_definition_v3(
    project: DICProjectV3,
    interactive: bool = True,
    programmatic_roi: Optional[Dict[str, Any]] = None,
) -> DICProjectV3:
    """
    Paso 3 del pipeline V3: definición de ROI y generación de grilla reducida.

    Parameters
    ----------
    project : DICProjectV3
        Proyecto con imágenes cargadas.
    interactive : bool
        Si es True, solicita la ROI interactivamente sobre la imagen de referencia.
    programmatic_roi : dict | None
        ROI programática cuando interactive=False.
        Soporta:
            {"type":"rectangular", "xmin":..., "xmax":..., "ymin":..., "ymax":..., "spacing_x":..., "spacing_y":...}
            {"type":"polygonal", "polygon": array_like Nx2, "spacing_x":..., "spacing_y":...}

    Returns
    -------
    DICProjectV3
        Proyecto actualizado con ROI y grilla.
    """
    if not project.is_ready_for("grid_defined"):
        raise RuntimeError("Primero deben cargarse las imágenes (paso 1).")

    with Timer("ROI + grilla V3", logger):
        if interactive:
            roi = _interactive_rect_roi(project)
        else:
            if programmatic_roi is None:
                raise ValueError("interactive=False requiere programmatic_roi.")
            roi = dict(programmatic_roi)
            roi.setdefault("type", "rectangular")
            roi.setdefault("spacing_x", project.config.roi.spacing_x)
            roi.setdefault("spacing_y", project.config.roi.spacing_y)

        roi_type = str(roi["type"]).lower().strip()
        if roi_type in ["rectangular", "rectangle", "rect"]:
            roi["type"] = "rectangular"
            gx, gy = _rect_grid_from_roi(project, roi)
        elif roi_type in ["polygonal", "polygon", "poly"]:
            roi["type"] = "polygonal"
            gx, gy = _polygon_grid_from_roi(project, roi)
        else:
            raise ValueError(f"Tipo de ROI no soportado: {roi_type}")

        _store_roi_and_grid(project, roi, gx, gy)

        logger.info(
            "ROI aceptada: tipo=%s | puntos=%d | spacing=(%d,%d) | grid_shape=%s",
            project.roi.type,
            project.num_points,
            int(project.spacing_x),
            int(project.spacing_y),
            project.grid_shape,
        )

    project.mark_step("grid_defined")
    _show_grid_overlay(project, title="ROI + grilla reducida V3")
    return project


__all__ = [
    "run_grid_definition_v3",
]
