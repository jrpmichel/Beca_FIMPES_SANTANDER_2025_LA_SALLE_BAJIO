# -*- coding: utf-8 -*-
"""
DIC_2D_V3

Paquete base del pipeline DIC 2D V3.

Exporta las clases y funciones principales para facilitar imports
desde scripts externos o pruebas rápidas.
"""

from .config import DICConfigV3
from .project import DICProjectV3
from .utils import setup_logging_v3, Timer

from .image_loader import run_image_loader_v3
from .calibration import run_calibration_v3
from .roi_grid import run_grid_definition_v3
from .correlation_engine import run_correlation_v3
from .displacement import run_displacement_v3
from .strain import run_strain_v3
from .visualization import (
    plot_dashboard_v3,
    plot_quiver_v3,
    plot_field_map_v3,
    plot_strain_vs_frame_v3,
    plot_strain_vs_max_displacement_v3,
)
from .uncertainty import run_uncertainty_v3

__all__ = [
    "DICConfigV3",
    "DICProjectV3",
    "setup_logging_v3",
    "Timer",
    "run_image_loader_v3",
    "run_calibration_v3",
    "run_grid_definition_v3",
    "run_correlation_v3",
    "run_displacement_v3",
    "run_strain_v3",
    "plot_dashboard_v3",
    "plot_quiver_v3",
    "plot_field_map_v3",
    "plot_strain_vs_frame_v3",
    "plot_strain_vs_max_displacement_v3",
    "run_uncertainty_v3",
]
