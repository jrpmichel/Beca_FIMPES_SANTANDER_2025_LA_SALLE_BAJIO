# -*- coding: utf-8 -*-
"""
DIC_2D_V3/strain.py

Cálculo de gradientes de desplazamiento y tensores de deformación para DIC_2D_V3.

Filosofía V3
------------
- Mantener compatibilidad con el flujo inspirado en NCorr.
- Separar explícitamente:
    1) cálculo de gradientes de desplazamiento (dispgrad),
    2) armado del tensor de strain.
- Trabajar con unidades espaciales consistentes:
    * si existen desplazamientos en mm y mm_per_px válido, se derivan en mm/mm;
    * si no, se derivan en px/px.
- Interpretar `strain_radius` como un radio sobre la grilla reducida,
  no como un número arbitrario de vecinos.

Métodos soportados
------------------
- engine="ncorr_dispgrad": gradientes locales por ajuste LSQ lineal sobre vecindad circular.
- engine="gradient": diferencias finitas sobre grilla regular.
- engine="green_lagrange": atajo equivalente a dispgrad + tensor green_lagrange.
- engine="eulerian_almansi": atajo equivalente a dispgrad + tensor eulerian_almansi.

Notas
-----
- Este módulo no depende de red neuronal.
- El resultado de strain es adimensional. La visualización puede mostrarse en µε.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np

from .project import DICProjectV3
from .utils import Timer, robust_limits, to_microstrain

logger = logging.getLogger("dic2d.v3.strain")


# =====================================================================
# Helpers de grilla / unidades
# =====================================================================
def _require_regular_grid(project: DICProjectV3) -> Tuple[int, int]:
    if project.grid_shape is None:
        raise ValueError("run_strain_v3 requiere una grilla regular (project.grid_shape).")
    ny, nx = project.grid_shape
    return int(ny), int(nx)


def _select_metric_fields(project: DICProjectV3) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, str]:
    """
    Selecciona desplazamientos y coordenadas espaciales en unidades consistentes.

    Prioridad:
    1) mm, si existen disp_x_mm/disp_y_mm y mm_per_px válido.
    2) px, en cualquier otro caso.
    """
    if project.grid_x is None or project.grid_y is None:
        raise ValueError("No existe grilla en el proyecto.")

    gx_px = np.asarray(project.grid_x, dtype=float).ravel()
    gy_px = np.asarray(project.grid_y, dtype=float).ravel()

    mm_per_px = getattr(project.calibration, "mm_per_px", None)
    has_mm = (
        project.disp_x_mm is not None and
        project.disp_y_mm is not None and
        mm_per_px is not None and
        np.isfinite(mm_per_px) and
        float(mm_per_px) > 0
    )

    if has_mm:
        gx = gx_px * float(mm_per_px)
        gy = gy_px * float(mm_per_px)
        U = np.asarray(project.disp_x_mm, dtype=float)
        V = np.asarray(project.disp_y_mm, dtype=float)
        return U, V, gx, gy, "mm"

    if project.disp_x_px is not None and project.disp_y_px is not None:
        U = np.asarray(project.disp_x_px, dtype=float)
        V = np.asarray(project.disp_y_px, dtype=float)
    elif project.disp_x is not None and project.disp_y is not None:
        U = np.asarray(project.disp_x, dtype=float)
        V = np.asarray(project.disp_y, dtype=float)
    else:
        raise ValueError("No existen campos de desplazamiento válidos en el proyecto.")

    return U, V, gx_px, gy_px, "px"


def _reshape_field(field: np.ndarray, ny: int, nx: int) -> np.ndarray:
    arr = np.asarray(field, dtype=float).ravel()
    if arr.size != ny * nx:
        raise ValueError(f"El campo no coincide con la grilla: {arr.size} != {ny*nx}")
    return arr.reshape(ny, nx)


def _flatten_field(field2d: np.ndarray) -> np.ndarray:
    return np.asarray(field2d, dtype=float).reshape(-1)


# =====================================================================
# Geometría local para dispgrad tipo NCorr
# =====================================================================
def _build_circular_offsets(radius: int) -> np.ndarray:
    r = int(radius)
    offs = []
    for dj in range(-r, r + 1):
        for di in range(-r, r + 1):
            if di * di + dj * dj <= r * r:
                offs.append((dj, di))
    return np.asarray(offs, dtype=int)


def _prepare_local_design_matrix(dx: float, dy: float, radius: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Matriz de diseño para ajuste lineal local:
        z(x,y) ≈ a0 + a1*x + a2*y

    Se usa una vecindad circular expresada en índices de grilla y convertida a
    coordenadas espaciales mediante dx, dy.
    """
    offsets = _build_circular_offsets(radius)
    xx = offsets[:, 1].astype(float) * float(dx)
    yy = offsets[:, 0].astype(float) * float(dy)
    A = np.column_stack([np.ones_like(xx), xx, yy])
    return A, offsets


def _solve_local_plane(values: np.ndarray, A: np.ndarray) -> Tuple[float, float, float]:
    valid = np.isfinite(values)
    if np.count_nonzero(valid) < 6:
        return np.nan, np.nan, np.nan

    Av = A[valid]
    zv = values[valid]

    try:
        coef, *_ = np.linalg.lstsq(Av, zv, rcond=None)
    except np.linalg.LinAlgError:
        return np.nan, np.nan, np.nan

    return float(coef[0]), float(coef[1]), float(coef[2])


# =====================================================================
# Dispgrad
# =====================================================================
def _dispgrad_ncorrag_like(
    U: np.ndarray,
    V: np.ndarray,
    gx: np.ndarray,
    gy: np.ndarray,
    ny: int,
    nx: int,
    strain_radius: int,
    exclude_boundary: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Gradientes de desplazamiento sobre grilla regular mediante ajuste LSQ local.

    Este método es una aproximación razonable al concepto de `dispgrad + strain radius`
    de NCorr: en cada nodo se ajusta localmente un plano lineal sobre una vecindad
    circular y se extraen las derivadas parciales del desplazamiento.
    """
    gx2d = _reshape_field(gx, ny, nx)
    gy2d = _reshape_field(gy, ny, nx)

    # Se asume grilla uniforme.
    dx_vals = np.diff(np.unique(np.round(gx2d[0, :], 12)))
    dy_vals = np.diff(np.unique(np.round(gy2d[:, 0], 12)))
    dx = float(np.mean(dx_vals)) if dx_vals.size > 0 else 1.0
    dy = float(np.mean(dy_vals)) if dy_vals.size > 0 else 1.0

    A, offsets = _prepare_local_design_matrix(dx=dx, dy=dy, radius=strain_radius)

    n_points, n_frames = U.shape
    du_dx = np.full((n_points, n_frames), np.nan, dtype=float)
    du_dy = np.full((n_points, n_frames), np.nan, dtype=float)
    dv_dx = np.full((n_points, n_frames), np.nan, dtype=float)
    dv_dy = np.full((n_points, n_frames), np.nan, dtype=float)

    r = int(strain_radius)

    for k in range(n_frames):
        U2 = _reshape_field(U[:, k], ny, nx)
        V2 = _reshape_field(V[:, k], ny, nx)

        j_start = r if exclude_boundary else 0
        j_stop = ny - r if exclude_boundary else ny
        i_start = r if exclude_boundary else 0
        i_stop = nx - r if exclude_boundary else nx

        for j in range(j_start, j_stop):
            for i in range(i_start, i_stop):
                jj = j + offsets[:, 0]
                ii = i + offsets[:, 1]

                inside = (jj >= 0) & (jj < ny) & (ii >= 0) & (ii < nx)
                if np.count_nonzero(inside) < 6:
                    continue

                u_vals = np.full(offsets.shape[0], np.nan, dtype=float)
                v_vals = np.full(offsets.shape[0], np.nan, dtype=float)
                u_vals[inside] = U2[jj[inside], ii[inside]]
                v_vals[inside] = V2[jj[inside], ii[inside]]

                _, a1, a2 = _solve_local_plane(u_vals, A)
                _, b1, b2 = _solve_local_plane(v_vals, A)

                p = j * nx + i
                du_dx[p, k] = a1
                du_dy[p, k] = a2
                dv_dx[p, k] = b1
                dv_dy[p, k] = b2

    return du_dx, du_dy, dv_dx, dv_dy


def _dispgrad_gradient(
    U: np.ndarray,
    V: np.ndarray,
    gx: np.ndarray,
    gy: np.ndarray,
    ny: int,
    nx: int,
    exclude_boundary: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Gradientes por np.gradient sobre grilla regular."""
    gx2d = _reshape_field(gx, ny, nx)
    gy2d = _reshape_field(gy, ny, nx)

    dx_vals = np.diff(np.unique(np.round(gx2d[0, :], 12)))
    dy_vals = np.diff(np.unique(np.round(gy2d[:, 0], 12)))
    dx = float(np.mean(dx_vals)) if dx_vals.size > 0 else 1.0
    dy = float(np.mean(dy_vals)) if dy_vals.size > 0 else 1.0

    n_points, n_frames = U.shape
    du_dx = np.full((n_points, n_frames), np.nan, dtype=float)
    du_dy = np.full((n_points, n_frames), np.nan, dtype=float)
    dv_dx = np.full((n_points, n_frames), np.nan, dtype=float)
    dv_dy = np.full((n_points, n_frames), np.nan, dtype=float)

    for k in range(n_frames):
        U2 = _reshape_field(U[:, k], ny, nx)
        V2 = _reshape_field(V[:, k], ny, nx)

        dU_dy, dU_dx = np.gradient(U2, dy, dx)
        dV_dy, dV_dx = np.gradient(V2, dy, dx)

        if exclude_boundary:
            for Z in (dU_dx, dU_dy, dV_dx, dV_dy):
                Z[[0, -1], :] = np.nan
                Z[:, [0, -1]] = np.nan

        du_dx[:, k] = _flatten_field(dU_dx)
        du_dy[:, k] = _flatten_field(dU_dy)
        dv_dx[:, k] = _flatten_field(dV_dx)
        dv_dy[:, k] = _flatten_field(dV_dy)

    return du_dx, du_dy, dv_dx, dv_dy


# =====================================================================
# Tensores de strain
# =====================================================================
def _strain_infinitesimal(
    du_dx: np.ndarray,
    du_dy: np.ndarray,
    dv_dx: np.ndarray,
    dv_dy: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    exx = du_dx.copy()
    eyy = dv_dy.copy()
    exy = 0.5 * (du_dy + dv_dx)
    return exx, eyy, exy


def _strain_green_lagrange(
    du_dx: np.ndarray,
    du_dy: np.ndarray,
    dv_dx: np.ndarray,
    dv_dy: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    Exx = du_dx + 0.5 * (du_dx ** 2 + dv_dx ** 2)
    Eyy = dv_dy + 0.5 * (du_dy ** 2 + dv_dy ** 2)
    Exy = 0.5 * (du_dy + dv_dx + du_dx * du_dy + dv_dx * dv_dy)
    return Exx, Eyy, Exy


def _strain_eulerian_almansi(
    du_dx: np.ndarray,
    du_dy: np.ndarray,
    dv_dx: np.ndarray,
    dv_dy: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n_points, n_frames = du_dx.shape
    exx = np.full((n_points, n_frames), np.nan, dtype=float)
    eyy = np.full((n_points, n_frames), np.nan, dtype=float)
    exy = np.full((n_points, n_frames), np.nan, dtype=float)

    I2 = np.eye(2, dtype=float)

    for k in range(n_frames):
        for p in range(n_points):
            a = du_dx[p, k]
            b = du_dy[p, k]
            c = dv_dx[p, k]
            d = dv_dy[p, k]
            if not np.isfinite(a + b + c + d):
                continue

            F = np.array([[1.0 + a, b], [c, 1.0 + d]], dtype=float)
            bten = F @ F.T
            try:
                b_inv = np.linalg.inv(bten)
            except np.linalg.LinAlgError:
                continue

            e = 0.5 * (I2 - b_inv)
            exx[p, k] = e[0, 0]
            eyy[p, k] = e[1, 1]
            exy[p, k] = e[0, 1]

    return exx, eyy, exy


def _compute_principal_strains(
    exx: np.ndarray,
    eyy: np.ndarray,
    exy: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    avg = 0.5 * (exx + eyy)
    diff = 0.5 * (exx - eyy)
    R = np.sqrt(diff ** 2 + exy ** 2)

    e1 = avg + R
    e2 = avg - R
    theta = np.where(
        np.abs(exx - eyy) > 1e-15,
        0.5 * np.arctan2(2.0 * exy, exx - eyy),
        np.where(np.abs(exy) > 1e-15, np.sign(exy) * np.pi / 4.0, 0.0),
    )
    return e1, e2, theta


# =====================================================================
# Visualización resumida
# =====================================================================
def _show_strain_summary(project: DICProjectV3) -> None:
    try:
        import matplotlib.pyplot as plt

        if project.strain_xx is None or project.strain_yy is None:
            return

        gx = np.asarray(project.grid_x, dtype=float)
        gy = np.asarray(project.grid_y, dtype=float)
        last = int(project.strain_xx.shape[1] - 1)

        unit_mode = str(project.config.imaging.strain_display_units).lower().strip()
        factor = 1e6 if unit_mode == "microstrain" else 1.0
        suffix = " [µε]" if unit_mode == "microstrain" else ""

        fields = [
            (project.strain_xx[:, last] * factor, f"εxx{suffix}", "RdBu_r"),
            (project.strain_yy[:, last] * factor, f"εyy{suffix}", "RdBu_r"),
        ]
        if project.strain_xy is not None:
            fields.append((project.strain_xy[:, last] * factor, f"εxy{suffix}", "PuOr"))

        fig, axes = plt.subplots(1, len(fields), figsize=(5.6 * len(fields), 5))
        if len(fields) == 1:
            axes = [axes]
        fig.suptitle(f"Strain V3 - frame {last+1}", fontsize=12)

        for ax, (data, title, cmap) in zip(axes, fields):
            mask = np.isfinite(data)
            if np.count_nonzero(mask) == 0:
                ax.set_title(f"{title} - sin datos")
                continue
            vmin, vmax = robust_limits(data[mask], p_low=2, p_high=98, symmetric=True)
            sc = ax.scatter(
                gx[mask], gy[mask], c=data[mask], s=12, cmap=cmap,
                edgecolors="none", vmin=vmin, vmax=vmax
            )
            plt.colorbar(sc, ax=ax, shrink=0.75)
            ax.set_title(title)
            ax.set_aspect("equal")
            ax.invert_yaxis()
            ax.axis("off")

        plt.tight_layout()
        plt.show(block=False)
        plt.pause(0.5)
    except Exception as exc:  # pragma: no cover
        logger.warning("No se pudo mostrar resumen de strain: %s", exc)


# =====================================================================
# API principal
# =====================================================================
def run_strain_v3(project: DICProjectV3, show_summary: bool = True) -> DICProjectV3:
    if not project.is_ready_for("strain_done"):
        raise RuntimeError("Primero debe completar desplazamientos (displacement_done).")

    if project.disp_x is None or project.disp_y is None:
        raise ValueError("No existen campos de desplazamiento en el proyecto.")

    ny, nx = _require_regular_grid(project)
    cfg = project.config.strain
    method = str(cfg.engine).lower().strip()
    tensor = str(cfg.tensor).lower().strip()

    U, V, gx, gy, unit = _select_metric_fields(project)

    with Timer("Strain V3", logger):
        # ------------------------------------------------------------
        # Gradientes de desplazamiento
        # ------------------------------------------------------------
        if method == "ncorr_dispgrad":
            du_dx, du_dy, dv_dx, dv_dy = _dispgrad_ncorrag_like(
                U=U,
                V=V,
                gx=gx,
                gy=gy,
                ny=ny,
                nx=nx,
                strain_radius=int(cfg.strain_radius),
                exclude_boundary=bool(cfg.exclude_boundary),
            )
        elif method == "gradient":
            du_dx, du_dy, dv_dx, dv_dy = _dispgrad_gradient(
                U=U,
                V=V,
                gx=gx,
                gy=gy,
                ny=ny,
                nx=nx,
                exclude_boundary=bool(cfg.exclude_boundary),
            )
        elif method in ["green_lagrange", "green-lagrange"]:
            du_dx, du_dy, dv_dx, dv_dy = _dispgrad_ncorrag_like(
                U=U,
                V=V,
                gx=gx,
                gy=gy,
                ny=ny,
                nx=nx,
                strain_radius=int(cfg.strain_radius),
                exclude_boundary=bool(cfg.exclude_boundary),
            )
            tensor = "green_lagrange"
        elif method in ["eulerian_almansi", "eulerian-almansi"]:
            du_dx, du_dy, dv_dx, dv_dy = _dispgrad_ncorrag_like(
                U=U,
                V=V,
                gx=gx,
                gy=gy,
                ny=ny,
                nx=nx,
                strain_radius=int(cfg.strain_radius),
                exclude_boundary=bool(cfg.exclude_boundary),
            )
            tensor = "eulerian_almansi"
        else:
            raise ValueError(f"Engine de strain no soportado: {cfg.engine}")

        # Guardar gradientes
        project.du_dx = du_dx
        project.du_dy = du_dy
        project.dv_dx = dv_dx
        project.dv_dy = dv_dy

        # ------------------------------------------------------------
        # Tensor de deformación
        # ------------------------------------------------------------
        if tensor in ["infinitesimal", "small", "small_strain"]:
            exx, eyy, exy = _strain_infinitesimal(du_dx, du_dy, dv_dx, dv_dy)
        elif tensor in ["green_lagrange", "green-lagrange"]:
            exx, eyy, exy = _strain_green_lagrange(du_dx, du_dy, dv_dx, dv_dy)
        elif tensor in ["eulerian_almansi", "eulerian-almansi", "almansi"]:
            exx, eyy, exy = _strain_eulerian_almansi(du_dx, du_dy, dv_dx, dv_dy)
        else:
            raise ValueError(f"Tensor de strain no soportado: {cfg.tensor}")

    project.strain_xx = exx
    project.strain_yy = eyy
    project.strain_xy = exy if bool(cfg.compute_shear) else None

    if bool(cfg.compute_principal) and project.strain_xy is not None:
        e1, e2, theta = _compute_principal_strains(project.strain_xx, project.strain_yy, project.strain_xy)
        project.strain_e1 = e1
        project.strain_e2 = e2
        project.strain_theta = theta
    else:
        project.strain_e1 = None
        project.strain_e2 = None
        project.strain_theta = None

    project.strain_meta = {
        "engine": method,
        "tensor": tensor,
        "strain_radius": int(cfg.strain_radius),
        "exclude_boundary": bool(cfg.exclude_boundary),
        "compute_shear": bool(cfg.compute_shear),
        "compute_principal": bool(cfg.compute_principal),
        "unit_system_for_dispgrad": unit,
        "grid_shape": tuple(project.grid_shape) if project.grid_shape is not None else None,
        "du_dx_range": (float(np.nanmin(project.du_dx)), float(np.nanmax(project.du_dx))),
        "du_dy_range": (float(np.nanmin(project.du_dy)), float(np.nanmax(project.du_dy))),
        "dv_dx_range": (float(np.nanmin(project.dv_dx)), float(np.nanmax(project.dv_dx))),
        "dv_dy_range": (float(np.nanmin(project.dv_dy)), float(np.nanmax(project.dv_dy))),
        "strain_xx_range": (float(np.nanmin(project.strain_xx)), float(np.nanmax(project.strain_xx))),
        "strain_yy_range": (float(np.nanmin(project.strain_yy)), float(np.nanmax(project.strain_yy))),
        "strain_xy_range": (
            None if project.strain_xy is None else float(np.nanmin(project.strain_xy)),
            None if project.strain_xy is None else float(np.nanmax(project.strain_xy)),
        ),
    }

    logger.info(
        "Strain V3: engine=%s | tensor=%s | radius=%d | unidades=%s",
        method,
        tensor,
        int(cfg.strain_radius),
        unit,
    )
    logger.info(
        "εxx=[%.6e, %.6e] | εyy=[%.6e, %.6e] | εxy=[%.6e, %.6e]",
        float(np.nanmin(project.strain_xx)), float(np.nanmax(project.strain_xx)),
        float(np.nanmin(project.strain_yy)), float(np.nanmax(project.strain_yy)),
        float(np.nanmin(project.strain_xy)) if project.strain_xy is not None else float("nan"),
        float(np.nanmax(project.strain_xy)) if project.strain_xy is not None else float("nan"),
    )

    # Exportación básica
    out_dir = Path(project.config.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    np.savetxt(out_dir / "strain_xx_v3.dat", project.strain_xx, delimiter="\t", fmt="%.8e")
    np.savetxt(out_dir / "strain_yy_v3.dat", project.strain_yy, delimiter="\t", fmt="%.8e")
    if project.strain_xy is not None:
        np.savetxt(out_dir / "strain_xy_v3.dat", project.strain_xy, delimiter="\t", fmt="%.8e")

    if str(project.config.imaging.strain_display_units).lower().strip() == "microstrain":
        np.savetxt(out_dir / "strain_xx_v3_microstrain.dat", to_microstrain(project.strain_xx), delimiter="\t", fmt="%.3f")
        np.savetxt(out_dir / "strain_yy_v3_microstrain.dat", to_microstrain(project.strain_yy), delimiter="\t", fmt="%.3f")
        if project.strain_xy is not None:
            np.savetxt(out_dir / "strain_xy_v3_microstrain.dat", to_microstrain(project.strain_xy), delimiter="\t", fmt="%.3f")

    project.mark_step("strain_done")

    if show_summary:
        _show_strain_summary(project)

    return project


__all__ = ["run_strain_v3"]
