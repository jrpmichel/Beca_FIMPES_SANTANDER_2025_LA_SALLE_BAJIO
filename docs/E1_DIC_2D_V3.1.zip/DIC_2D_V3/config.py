# -*- coding: utf-8 -*-
"""
DIC_2D_V3/config.py

Configuración central del pipeline DIC_2D_V3.

Diseño:
- Parámetros agrupados por responsabilidad.
- Estilo cercano a NCorr para subset radius, spacing, cutoff_diffnorm,
  cutoff_iteration y strain radius.
- Compatible con run_dic_V3.py.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from pprint import pformat
from typing import Any, Dict, Literal, Optional


# =====================================================================
# Sub-configuraciones
# =====================================================================
@dataclass
class ComputeConfigV3:
    use_gpu: bool = True
    gpu_backend: Literal["torch", "none"] = "torch"
    gpu_device: Literal["auto", "cuda", "cpu"] = "auto"
    gpu_for_correlation: bool = False
    gpu_for_visualization: bool = True
    num_threads: int = 0


@dataclass
class ImagingConfigV3:
    apply_calibration: bool = True
    interactive_calibration: bool = True
    use_saved_calibration_if_available: bool = True
    distortion_correction: bool = True
    output_units: Literal["px", "mm"] = "mm"
    strain_display_units: Literal["strain", "microstrain"] = "microstrain"


@dataclass
class ROIConfigV3:
    interactive: bool = True
    type: Literal["rectangular", "polygonal"] = "rectangular"
    xmin: Optional[float] = None
    xmax: Optional[float] = None
    ymin: Optional[float] = None
    ymax: Optional[float] = None
    spacing_x: int = 15
    spacing_y: int = 15


@dataclass
class DICEngineConfigV3:
    # Parámetros tipo NCorr
    subset_radius: int = 27
    subset_size: int = 55
    spacing: int = 15
    cutoff_diffnorm: float = 1e-6
    cutoff_iteration: int = 50
    step_analysis: bool = True
    subset_truncation: bool = True
    corrcoef_min: float = 0.60

    # Búsqueda / propagación
    search_radius: int = 30
    mode: Literal["incremental", "absolute"] = "incremental"
    seed_strategy: Literal["propagation", "manual", "auto"] = "propagation"
    use_predictor: bool = True

    # Núcleo numérico
    engine: Literal["rgdic", "icgn"] = "rgdic"
    interpolation: Literal["bilinear", "bicubic"] = "bicubic"
    warp: Literal["translation", "affine"] = "affine"

    def sync_subset_size(self) -> None:
        self.subset_size = 2 * int(self.subset_radius) + 1

    def sync_subset_radius(self) -> None:
        if int(self.subset_size) % 2 == 0:
            raise ValueError("subset_size debe ser impar.")
        self.subset_radius = (int(self.subset_size) - 1) // 2


@dataclass
class DisplacementConfigV3:
    outlier_method: str = "corrcoef+median"
    median_threshold: float = 2.5
    spatial_smoothing: Literal["none", "gaussian", "median"] = "gaussian"
    smoothing_kernel: int = 3
    fill_missing: bool = True
    fill_method: Literal["nearest", "linear", "cubic", "griddata"] = "griddata"
    export_displacements_in_mm: bool = True


@dataclass
class StrainConfigV3:
    engine: Literal[
        "ncorr_dispgrad", "gradient", "green_lagrange", "eulerian_almansi"
    ] = "ncorr_dispgrad"
    strain_radius: int = 5
    tensor: Literal["infinitesimal", "green_lagrange", "eulerian_almansi"] = "infinitesimal"
    compute_shear: bool = True
    compute_principal: bool = True
    exclude_boundary: bool = True


@dataclass
class UncertaintyConfigV3:
    enabled: bool = True
    mode: Literal["gum", "none"] = "gum"


@dataclass
class VisualizationConfigV3:
    dpi: int = 180
    export_format: Literal["png", "pdf", "svg"] = "png"
    show_progress_correlation: bool = True
    smooth_method: Literal["bspline", "torch_bicubic"] = "bspline"
    upsample_nx: int = 320
    upsample_ny: int = 320
    levels: int = 140
    quiver_skip: int = 6
    quiver_gain: float = 5.0
    show_dashboard: bool = True
    show_field_maps: bool = True
    show_strain_vs_frame: bool = True
    show_strain_vs_dmax: bool = True


# =====================================================================
# Configuración principal
# =====================================================================
@dataclass
class DICConfigV3:
    project_name: str
    image_dir: str
    image_pattern: str
    output_dir: str

    compute: ComputeConfigV3 = field(default_factory=ComputeConfigV3)
    imaging: ImagingConfigV3 = field(default_factory=ImagingConfigV3)
    roi: ROIConfigV3 = field(default_factory=ROIConfigV3)
    dic: DICEngineConfigV3 = field(default_factory=DICEngineConfigV3)
    displacement: DisplacementConfigV3 = field(default_factory=DisplacementConfigV3)
    strain: StrainConfigV3 = field(default_factory=StrainConfigV3)
    uncertainty: UncertaintyConfigV3 = field(default_factory=UncertaintyConfigV3)
    visualization: VisualizationConfigV3 = field(default_factory=VisualizationConfigV3)

    def __post_init__(self) -> None:
        self.project_name = str(self.project_name).strip()
        self.image_dir = str(self.image_dir)
        self.image_pattern = str(self.image_pattern)
        self.output_dir = str(self.output_dir)
        self.validate()

    # -----------------------------------------------------------------
    # Validación
    # -----------------------------------------------------------------
    def validate(self) -> None:
        if not self.project_name:
            raise ValueError("project_name no puede estar vacío.")

        if not self.image_pattern:
            raise ValueError("image_pattern no puede estar vacío.")

        if self.roi.spacing_x <= 0 or self.roi.spacing_y <= 0:
            raise ValueError("ROI.spacing_x y ROI.spacing_y deben ser > 0.")

        if self.dic.subset_radius <= 0:
            raise ValueError("dic.subset_radius debe ser > 0.")
        self.dic.sync_subset_size()

        if self.dic.spacing <= 0:
            raise ValueError("dic.spacing debe ser > 0.")

        if self.dic.search_radius < 0:
            raise ValueError("dic.search_radius debe ser >= 0.")

        if self.dic.cutoff_diffnorm <= 0:
            raise ValueError("dic.cutoff_diffnorm debe ser > 0.")

        if self.dic.cutoff_iteration <= 0:
            raise ValueError("dic.cutoff_iteration debe ser > 0.")

        if not (0.0 <= self.dic.corrcoef_min <= 1.0):
            raise ValueError("dic.corrcoef_min debe estar en [0, 1].")

        if self.displacement.smoothing_kernel < 1:
            raise ValueError("displacement.smoothing_kernel debe ser >= 1.")

        if self.strain.strain_radius < 1:
            raise ValueError("strain.strain_radius debe ser >= 1.")

        if self.visualization.upsample_nx < 16 or self.visualization.upsample_ny < 16:
            raise ValueError("visualization.upsample_nx/ny deben ser >= 16.")

        if self.visualization.levels < 8:
            raise ValueError("visualization.levels debe ser >= 8.")

    # -----------------------------------------------------------------
    # Utilidades
    # -----------------------------------------------------------------
    @property
    def image_dir_path(self) -> Path:
        return Path(self.image_dir)

    @property
    def output_dir_path(self) -> Path:
        return Path(self.output_dir)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DICConfigV3":
        base_keys = {"project_name", "image_dir", "image_pattern", "output_dir"}
        missing = [k for k in base_keys if k not in data]
        if missing:
            raise KeyError(f"Faltan claves base en config: {missing}")

        cfg = cls(
            project_name=data["project_name"],
            image_dir=data["image_dir"],
            image_pattern=data["image_pattern"],
            output_dir=data["output_dir"],
        )

        # Sobrescribir subconfiguraciones si existen
        submaps = {
            "compute": (cfg.compute, ComputeConfigV3),
            "imaging": (cfg.imaging, ImagingConfigV3),
            "roi": (cfg.roi, ROIConfigV3),
            "dic": (cfg.dic, DICEngineConfigV3),
            "displacement": (cfg.displacement, DisplacementConfigV3),
            "strain": (cfg.strain, StrainConfigV3),
            "uncertainty": (cfg.uncertainty, UncertaintyConfigV3),
            "visualization": (cfg.visualization, VisualizationConfigV3),
        }

        for key, (obj, _) in submaps.items():
            if key in data and isinstance(data[key], dict):
                for subkey, value in data[key].items():
                    if hasattr(obj, subkey):
                        setattr(obj, subkey, value)

        cfg.validate()
        return cfg

    def summary(self) -> str:
        d = self.to_dict()
        return pformat(d, sort_dicts=False, compact=False)


__all__ = [
    "ComputeConfigV3",
    "ImagingConfigV3",
    "ROIConfigV3",
    "DICEngineConfigV3",
    "DisplacementConfigV3",
    "StrainConfigV3",
    "UncertaintyConfigV3",
    "VisualizationConfigV3",
    "DICConfigV3",
]
