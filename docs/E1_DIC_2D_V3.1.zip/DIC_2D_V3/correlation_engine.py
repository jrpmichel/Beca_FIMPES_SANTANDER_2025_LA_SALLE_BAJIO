# -*- coding: utf-8 -*-
"""
DIC_2D_V3/correlation_engine.py

Motor de correlación V3 con step-analysis incremental real.

Idea principal
--------------
Para cada punto de la grilla:
- En modo incremental, el template del frame k se toma alrededor de la
  posición material alcanzada en el frame k-1.
- Se busca el incremento pequeño en la imagen k.
- Se acumula desplazamiento total respecto a la referencia inicial.

Esto corrige el vicio del motor anterior, que se comportaba como si el
incremental fuera solo un predictor superficial sin mover realmente el
centro material del subset.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

from .project import DICProjectV3
from .utils import Timer

logger = logging.getLogger("dic2d.v3.correlation")


# =====================================================================
# Config local
# =====================================================================
@dataclass
class CorrOptions:
    subset_radius: int
    search_radius: int
    corrcoef_min: float
    mode: str
    use_predictor: bool
    interpolation: str
    show_progress: bool = False


# =====================================================================
# Helpers básicos
# =====================================================================
def _as_float32_gray(img: np.ndarray) -> np.ndarray:
    arr = np.asarray(img)
    if arr.ndim == 3:
        arr = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
    arr = arr.astype(np.float32, copy=False)
    if arr.max() > 1.5:
        arr = arr / 255.0
    return arr


def _interp_flag(name: str) -> int:
    name = str(name).lower().strip()
    if name == "bilinear":
        return cv2.INTER_LINEAR
    return cv2.INTER_CUBIC


def _inside_image(x: float, y: float, radius: int, h: int, w: int) -> bool:
    return (x >= radius) and (x < (w - radius)) and (y >= radius) and (y < (h - radius))


def _extract_patch(img: np.ndarray, x: float, y: float, radius: int, interpolation: int) -> Optional[np.ndarray]:
    h, w = img.shape[:2]
    if not _inside_image(x, y, radius, h, w):
        return None
    size = 2 * radius + 1
    patch = cv2.getRectSubPix(img, (size, size), (float(x), float(y)))
    if patch is None:
        return None
    return patch.astype(np.float32, copy=False)


def _extract_search_window(
    img: np.ndarray,
    cx: float,
    cy: float,
    subset_radius: int,
    search_radius: int,
) -> Tuple[Optional[np.ndarray], Optional[Tuple[int, int]]]:
    """
    Extrae una ventana de búsqueda rectangular que contiene el template
    con margen de búsqueda.
    """
    h, w = img.shape[:2]
    r = subset_radius
    s = search_radius

    x0 = int(np.floor(cx)) - (r + s)
    y0 = int(np.floor(cy)) - (r + s)
    x1 = int(np.floor(cx)) + (r + s) + 1
    y1 = int(np.floor(cy)) + (r + s) + 1

    if x0 < 0 or y0 < 0 or x1 > w or y1 > h:
        return None, None

    win = img[y0:y1, x0:x1]
    return win.astype(np.float32, copy=False), (x0, y0)


def _template_quality_ok(template: np.ndarray, std_min: float = 0.01) -> bool:
    if template is None:
        return False
    if not np.all(np.isfinite(template)):
        return False
    return float(np.std(template)) >= std_min


def _parabolic_subpixel_1d(c_m1: float, c_0: float, c_p1: float) -> float:
    """
    Devuelve desplazamiento subpíxel en [-1, 1] usando ajuste parabólico.
    """
    denom = (c_m1 - 2.0 * c_0 + c_p1)
    if abs(denom) < 1e-12:
        return 0.0
    delta = 0.5 * (c_m1 - c_p1) / denom
    return float(np.clip(delta, -1.0, 1.0))


def _subpixel_peak_from_map(resp: np.ndarray, iy: int, ix: int) -> Tuple[float, float]:
    """
    Refinamiento subpíxel alrededor del máximo.
    """
    dy = 0.0
    dx = 0.0

    if 1 <= iy < resp.shape[0] - 1:
        dy = _parabolic_subpixel_1d(resp[iy - 1, ix], resp[iy, ix], resp[iy + 1, ix])

    if 1 <= ix < resp.shape[1] - 1:
        dx = _parabolic_subpixel_1d(resp[iy, ix - 1], resp[iy, ix], resp[iy, ix + 1])

    return dx, dy


def _match_template_ncc(
    template: np.ndarray,
    search_win: np.ndarray,
) -> Tuple[bool, float, float, float]:
    """
    Devuelve:
        ok, dx_local, dy_local, cc
    donde dx_local, dy_local están medidos respecto al centro nominal
    de la ventana de búsqueda.
    """
    if template is None or search_win is None:
        return False, np.nan, np.nan, np.nan

    th, tw = template.shape[:2]
    sh, sw = search_win.shape[:2]

    if sh < th or sw < tw:
        return False, np.nan, np.nan, np.nan

    resp = cv2.matchTemplate(search_win, template, cv2.TM_CCOEFF_NORMED)
    if resp is None or resp.size == 0:
        return False, np.nan, np.nan, np.nan

    _, cc, _, max_loc = cv2.minMaxLoc(resp)
    ix, iy = max_loc

    sub_dx, sub_dy = _subpixel_peak_from_map(resp, iy, ix)

    # Centro del mapa de respuesta esperado si no hubiera desplazamiento
    cx0 = (resp.shape[1] - 1) / 2.0
    cy0 = (resp.shape[0] - 1) / 2.0

    dx_local = (ix + sub_dx) - cx0
    dy_local = (iy + sub_dy) - cy0

    return True, float(dx_local), float(dy_local), float(cc)


# =====================================================================
# Lógica de correlación por punto
# =====================================================================
def _track_point_incremental(
    prev_img: np.ndarray,
    curr_img: np.ndarray,
    x0: float,
    y0: float,
    u_prev: float,
    v_prev: float,
    du_prev: float,
    dv_prev: float,
    opts: CorrOptions,
    recover_absolute: bool = True,
) -> Tuple[bool, float, float, float, float, float]:
    """
    Rastrea un punto entre prev_img y curr_img.

    Retorna:
        ok, u_total, v_total, du_inc, dv_inc, cc
    """
    interp = _interp_flag(opts.interpolation)
    r = opts.subset_radius
    s = opts.search_radius

    # Centro material en frame previo
    x_prev = x0 + u_prev
    y_prev = y0 + v_prev

    # Predictor incremental
    if opts.use_predictor:
        x_pred = x_prev + du_prev
        y_pred = y_prev + dv_prev
    else:
        x_pred = x_prev
        y_pred = y_prev

    template = _extract_patch(prev_img, x_prev, y_prev, r, interp)
    if not _template_quality_ok(template):
        return False, np.nan, np.nan, np.nan, np.nan, np.nan

    search_win, _ = _extract_search_window(curr_img, x_pred, y_pred, r, s)
    ok, dx_loc, dy_loc, cc = _match_template_ncc(template, search_win)
    if ok and np.isfinite(cc) and cc >= opts.corrcoef_min:
        du_inc = (x_pred - x_prev) + dx_loc
        dv_inc = (y_pred - y_prev) + dy_loc
        return True, u_prev + du_inc, v_prev + dv_inc, du_inc, dv_inc, cc

    # Fallback absoluto: template de referencia inicial contra frame actual
    if recover_absolute:
        ref_template = _extract_patch(prev_img, x0 + u_prev * 0.0, y0 + v_prev * 0.0, r, interp)
        # Mejor: usar referencia material inicial pura
        ref_template = _extract_patch(project_ref_img_global, x0, y0, r, interp) if project_ref_img_global is not None else ref_template

        if _template_quality_ok(ref_template):
            search_win_abs, _ = _extract_search_window(curr_img, x0 + u_prev, y0 + v_prev, r, max(s * 2, s + 4))
            ok2, dx_loc2, dy_loc2, cc2 = _match_template_ncc(ref_template, search_win_abs)
            if ok2 and np.isfinite(cc2) and cc2 >= opts.corrcoef_min:
                u_abs = u_prev + dx_loc2
                v_abs = v_prev + dy_loc2
                du_inc = u_abs - u_prev
                dv_inc = v_abs - v_prev
                return True, u_abs, v_abs, du_inc, dv_inc, cc2

    return False, np.nan, np.nan, np.nan, np.nan, np.nan


# referencia global auxiliar para fallback absoluto
project_ref_img_global: Optional[np.ndarray] = None


# =====================================================================
# Visualización opcional
# =====================================================================
def _show_progress_frame(
    curr_img: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    u: np.ndarray,
    v: np.ndarray,
    ok: np.ndarray,
    frame_idx: int,
    n_frames: int,
    cc_mean: float,
):
    import matplotlib.pyplot as plt

    plt.figure(2)
    plt.clf()
    plt.imshow(curr_img, cmap="gray")

    if np.any(ok):
        xx = x[ok] + u[ok]
        yy = y[ok] + v[ok]
        plt.scatter(xx, yy, s=8, c="lime", edgecolors="none")

    if np.any(~ok):
        xx = x[~ok]
        yy = y[~ok]
        plt.scatter(xx, yy, s=8, c="red", edgecolors="none")

    plt.title(f"V3 Corr {frame_idx+1}/{n_frames} | cc={cc_mean:.4f} | ok={int(np.sum(ok))}/{len(ok)}")
    plt.axis("off")
    plt.tight_layout()
    plt.pause(0.001)


# =====================================================================
# API principal
# =====================================================================
def run_correlation_v3(
    project: DICProjectV3,
    show_progress: bool = False,
    device: str = "cpu",
) -> DICProjectV3:
    """
    Correlación V3 con incremental real frame-to-frame.
    """
    global project_ref_img_global

    if project.images is None or len(project.images) < 2:
        raise ValueError("Se requieren al menos 2 imágenes cargadas.")
    if project.grid_x is None or project.grid_y is None:
        raise ValueError("No existe grilla/ROI en el proyecto.")

    imgs = [_as_float32_gray(im) for im in project.images]
    ref_img = imgs[0]
    project_ref_img_global = ref_img

    x = np.asarray(project.grid_x, dtype=float).ravel()
    y = np.asarray(project.grid_y, dtype=float).ravel()

    n_points = x.size
    n_frames = len(imgs) - 1

    cfg = project.config
    opts = CorrOptions(
        subset_radius=int(cfg.dic.subset_radius),
        search_radius=int(cfg.dic.search_radius),
        corrcoef_min=float(cfg.dic.corrcoef_min),
        mode=str(cfg.dic.mode).lower().strip(),
        use_predictor=bool(cfg.dic.use_predictor),
        interpolation=str(cfg.dic.interpolation),
        show_progress=bool(show_progress),
    )

    logger.info(
        "Correlación V3: engine=%s | mode=%s | subset_radius=%d | search_radius=%d | points=%d | frames=%d | device=%s",
        cfg.dic.engine, opts.mode, opts.subset_radius, opts.search_radius, n_points, n_frames, device
    )

    corr_u = np.full((n_points, n_frames), np.nan, dtype=float)
    corr_v = np.full((n_points, n_frames), np.nan, dtype=float)
    corr_coeff = np.full((n_points, n_frames), np.nan, dtype=float)
    corr_flags = np.zeros((n_points, n_frames), dtype=np.uint8)
    corr_p = np.full((n_points, n_frames, 6), np.nan, dtype=float)

    # Estado acumulado
    u_prev = np.zeros(n_points, dtype=float)
    v_prev = np.zeros(n_points, dtype=float)
    du_prev = np.zeros(n_points, dtype=float)
    dv_prev = np.zeros(n_points, dtype=float)

    with Timer("Correlación V3", logger):
        for k in range(n_frames):
            if opts.mode == "incremental":
                prev_img = imgs[k]
                curr_img = imgs[k + 1]
            else:
                prev_img = imgs[0]
                curr_img = imgs[k + 1]

            ok_frame = np.zeros(n_points, dtype=bool)

            for i in range(n_points):
                ok, u_tot, v_tot, du_inc, dv_inc, cc = _track_point_incremental(
                    prev_img=prev_img,
                    curr_img=curr_img,
                    x0=float(x[i]),
                    y0=float(y[i]),
                    u_prev=float(u_prev[i]),
                    v_prev=float(v_prev[i]),
                    du_prev=float(du_prev[i]),
                    dv_prev=float(dv_prev[i]),
                    opts=opts,
                    recover_absolute=True,
                )

                if ok:
                    corr_u[i, k] = u_tot
                    corr_v[i, k] = v_tot
                    corr_coeff[i, k] = cc
                    corr_flags[i, k] = 1

                    # p = [u, ux, uy, v, vx, vy] -> por ahora solo traslación
                    corr_p[i, k, 0] = u_tot
                    corr_p[i, k, 3] = v_tot

                    # actualizar estado
                    du_prev[i] = du_inc
                    dv_prev[i] = dv_inc
                    u_prev[i] = u_tot
                    v_prev[i] = v_tot
                    ok_frame[i] = True
                else:
                    # conservar predictor previo, pero marcar inválido
                    corr_flags[i, k] = 0

            cc_mean = float(np.nanmean(corr_coeff[ok_frame, k])) if np.any(ok_frame) else 0.0
            logger.info(
                "Frame %d/%d | cc_mean=%.4f | válidos=%d/%d",
                k + 1, n_frames, cc_mean, int(np.sum(ok_frame)), n_points
            )

            if opts.show_progress:
                _show_progress_frame(
                    curr_img=curr_img,
                    x=x,
                    y=y,
                    u=np.nan_to_num(corr_u[:, k], nan=0.0),
                    v=np.nan_to_num(corr_v[:, k], nan=0.0),
                    ok=ok_frame,
                    frame_idx=k,
                    n_frames=n_frames,
                    cc_mean=cc_mean,
                )

    project.corr_u = corr_u
    project.corr_v = corr_v
    project.corr_coeff = corr_coeff
    project.corr_flags = corr_flags
    project.corr_p = corr_p

    project.mark_step("correlation_done")
    return project


__all__ = ["run_correlation_v3"]