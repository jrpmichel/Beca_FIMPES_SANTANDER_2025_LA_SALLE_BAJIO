# -*- coding: utf-8 -*-
"""
DIC_2D_V3/uncertainty.py

Estimación base de incertidumbre GUM simplificada para DIC_2D_V3.

Cambios V3.1
-------------
- Incertidumbre combinada u_combined = sqrt(ux² + uy²) almacenada.
- Mejor propagación hacia strain: u_exx, u_eyy, u_exy con Lx/Ly correctos.
- Visualización con auto-escalado y unidades correctas.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Tuple

import numpy as np

from .project import DICProjectV3
from .utils import Timer

logger = logging.getLogger("dic2d.v3.uncertainty")


def _get_unit_used(project: DICProjectV3) -> str:
    meta = getattr(project, "displacement_meta", {}) or {}
    unit = str(meta.get("unit_used", "px")).lower().strip()
    return "mm" if unit == "mm" else "px"


def _get_mm_per_px(project: DICProjectV3):
    cal = getattr(project, "calibration", None)
    val = getattr(cal, "mm_per_px", None)
    try:
        val = float(val)
        if np.isfinite(val) and val > 0:
            return val
    except Exception:
        pass
    return None


def _effective_grid_spacing(project: DICProjectV3, unit: str = "px"):
    sx = float(project.spacing_x if project.spacing_x is not None else project.config.roi.spacing_x)
    sy = float(project.spacing_y if project.spacing_y is not None else project.config.roi.spacing_y)
    if unit == "mm":
        mm_per_px = _get_mm_per_px(project)
        if mm_per_px is None:
            raise ValueError("No existe mm_per_px válido.")
        sx *= mm_per_px
        sy *= mm_per_px
    return sx, sy


def _estimate_sigma_pixel(project: DICProjectV3) -> float:
    """Estimación conservadora de sigma en px."""
    cal = getattr(project, "calibration", None)
    for attr in ["reprojection_error_px", "stereo_rms_px"]:
        val = getattr(cal, attr, None)
        if val is not None:
            try:
                val = float(val)
                if np.isfinite(val) and val > 0:
                    return val
            except Exception:
                pass
    return 0.05  # valor conservador para DIC 2D subpíxel


def _corrcoef_penalty(project: DICProjectV3):
    cc = getattr(project, "corr_coeff", None)
    if cc is None:
        return None
    cc = np.asarray(cc, dtype=float)
    pen = np.full_like(cc, np.nan, dtype=float)
    m = np.isfinite(cc)
    if np.any(m):
        pen[m] = 1.0 + np.clip((1.0 - cc[m]) / 0.10, 0.0, 5.0)
    return pen


def _compute_displacement_uncertainty(project: DICProjectV3):
    """
    Incertidumbre de desplazamiento.
    Retorna: ux, uy, u_combined, meta
    """
    # Forma base
    if project.corr_u is not None:
        shape = project.corr_u.shape
    elif project.disp_x_px is not None:
        shape = project.disp_x_px.shape
    else:
        shape = project.disp_x.shape

    sigma_px = _estimate_sigma_pixel(project)
    sigma_field_px = np.full(shape, sigma_px, dtype=float)

    penalty = _corrcoef_penalty(project)
    if penalty is not None:
        sigma_field_px = sigma_field_px * np.where(np.isfinite(penalty), penalty, 1.0)

    unit_used = _get_unit_used(project)
    mm_per_px = _get_mm_per_px(project)

    if unit_used == "mm" and mm_per_px is not None:
        sigma_x = sigma_field_px * mm_per_px
        sigma_y = sigma_field_px * mm_per_px
        unit = "mm"
    else:
        sigma_x = sigma_field_px.copy()
        sigma_y = sigma_field_px.copy()
        unit = "px"

    # Incertidumbre combinada: u_d = sqrt(ux² + uy²)
    u_combined = np.sqrt(sigma_x**2 + sigma_y**2)

    meta = {
        "sigma_pixel_base_px": float(sigma_px),
        "unit_used": unit,
        "mm_per_px": mm_per_px,
        "quality_penalty_from_corrcoef": penalty is not None,
    }
    return sigma_x, sigma_y, u_combined, meta


def _compute_strain_uncertainty(project: DICProjectV3, ux, uy):
    """
    Propagación de incertidumbre a strain.

    strain ~ du/dx  =>  u(exx) ~ sqrt(2) * sigma_u / Lx
    donde Lx = 2 * strain_radius * spacing_x
    """
    if project.strain_xx is None or project.strain_yy is None:
        raise AttributeError("No existen campos de strain.")

    unit_used = _get_unit_used(project)
    sx, sy = _effective_grid_spacing(project, unit=unit_used)
    r = max(int(project.config.strain.strain_radius), 1)

    Lx = max(2.0 * r * sx, 1e-12)
    Ly = max(2.0 * r * sy, 1e-12)

    sigma_u = np.asarray(ux, dtype=float)
    sigma_v = np.asarray(uy, dtype=float)

    u_exx = np.sqrt(2.0) * sigma_u / Lx
    u_eyy = np.sqrt(2.0) * sigma_v / Ly

    term1 = np.sqrt(2.0) * sigma_u / Ly
    term2 = np.sqrt(2.0) * sigma_v / Lx
    u_exy = 0.5 * np.sqrt(term1**2 + term2**2)

    meta = {
        "strain_radius": int(r),
        "effective_Lx": float(Lx),
        "effective_Ly": float(Ly),
        "grid_spacing_x": float(sx),
        "grid_spacing_y": float(sy),
        "displacement_unit_used": unit_used,
    }
    return u_exx, u_eyy, u_exy, meta


def _show_uncertainty_summary(project: DICProjectV3) -> None:
    try:
        import matplotlib.pyplot as plt

        last = project.ux.shape[1] - 1
        gx = np.asarray(project.grid_x, dtype=float).ravel()
        gy = np.asarray(project.grid_y, dtype=float).ravel()

        unit_used = _get_unit_used(project)
        mm_per_px = _get_mm_per_px(project)
        if unit_used == "mm" and mm_per_px is not None:
            gx = gx * mm_per_px
            gy = gy * mm_per_px

        fields = [
            (project.ux[:, last], f"u(U) [{unit_used}]"),
            (project.uy[:, last], f"u(V) [{unit_used}]"),
            (project.u_combined[:, last] if project.u_combined is not None else None, f"u(|d|) [{unit_used}]"),
            (project.ustrain_xy[:, last] if project.ustrain_xy is not None else None, "u(εxy) [-]"),
        ]

        ncols = sum(1 for f, _ in fields if f is not None)
        if ncols == 0:
            return

        fig, axes = plt.subplots(1, ncols, figsize=(5.5 * ncols, 5))
        if ncols == 1:
            axes = [axes]

        idx = 0
        for field_data, title in fields:
            if field_data is None:
                continue
            ax = axes[idx]
            idx += 1

            data = np.asarray(field_data, dtype=float).ravel()
            valid = np.isfinite(data)
            if not np.any(valid):
                ax.set_title(f"{title} — sin datos")
                continue

            # Auto-escalado
            vmin = float(np.nanpercentile(data[valid], 1))
            vmax = float(np.nanpercentile(data[valid], 99))
            if abs(vmax - vmin) < 1e-15:
                vmax = vmin + 1e-6

            sc = ax.scatter(gx[valid], gy[valid], c=data[valid], cmap="viridis",
                            s=10, edgecolors="none", vmin=vmin, vmax=vmax)
            plt.colorbar(sc, ax=ax, shrink=0.75, format="%.2e")
            ax.set_title(title)
            ax.set_aspect("equal")
            ax.invert_yaxis()
            ax.axis("off")

        plt.tight_layout()
        out_dir = Path(project.config.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_dir / "uncertainty_summary.png", dpi=180, bbox_inches="tight")
        plt.show(block=False)
        plt.pause(0.5)
    except Exception as exc:
        logger.warning("No se pudo mostrar resumen de incertidumbre: %s", exc)


def _export_uncertainty(project: DICProjectV3) -> None:
    out_dir = Path(project.config.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    for name, arr in [
        ("ux.dat", project.ux),
        ("uy.dat", project.uy),
        ("u_combined.dat", project.u_combined),
        ("ustrain_xx.dat", project.ustrain_xx),
        ("ustrain_yy.dat", project.ustrain_yy),
        ("ustrain_xy.dat", project.ustrain_xy),
    ]:
        if arr is not None:
            np.savetxt(out_dir / name, np.asarray(arr, dtype=float),
                       delimiter="\t", fmt="%.8e")


def run_uncertainty_v3(project: DICProjectV3, show_summary: bool = True) -> DICProjectV3:
    if not project.is_ready_for("uncertainty_done"):
        raise RuntimeError("Primero debe completar strain.")

    cfg = project.config.uncertainty
    mode = str(cfg.mode).lower().strip()

    if mode == "none":
        logger.info("Incertidumbre desactivada (mode='none').")
        project.ux = None
        project.uy = None
        project.u_combined = None
        project.ustrain_xx = None
        project.ustrain_yy = None
        project.ustrain_xy = None
        project.uncertainty_meta = {"mode": "none"}
        project.mark_step("uncertainty_done")
        return project

    with Timer("Estimación de incertidumbre", logger):
        ux, uy, u_comb, meta_u = _compute_displacement_uncertainty(project)
        uxx, uyy, uxy, meta_s = _compute_strain_uncertainty(project, ux, uy)

    project.ux = ux
    project.uy = uy
    project.u_combined = u_comb
    project.ustrain_xx = uxx
    project.ustrain_yy = uyy
    project.ustrain_xy = uxy
    project.uncertainty_meta = {
        "mode": mode,
        "displacement": meta_u,
        "strain": meta_s,
    }

    _export_uncertainty(project)
    project.mark_step("uncertainty_done")

    def _rng(arr):
        m = np.isfinite(arr)
        if not np.any(m):
            return "[nan, nan]"
        return f"[{np.nanmin(arr):.6g}, {np.nanmax(arr):.6g}]"

    logger.info("u(U)=%s | u(V)=%s | u(|d|)=%s",
                _rng(ux), _rng(uy), _rng(u_comb))
    if uxx is not None:
        logger.info("u(εxx)=%s | u(εyy)=%s | u(εxy)=%s",
                    _rng(uxx), _rng(uyy), _rng(uxy))

    if show_summary:
        _show_uncertainty_summary(project)
    return project
