# -*- coding: utf-8 -*-
"""
DIC_2D_V3/utils.py

Utilidades comunes del pipeline DIC_2D_V3.

Incluye:
- configuración homogénea de logging
- cronómetro de bloques (Timer)
- validaciones ligeras
- ayudas de conversión / resumen
"""

from __future__ import annotations

import logging
import math
import os
import time
from contextlib import ContextDecorator
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np


# =====================================================================
# Logging
# =====================================================================
def setup_logging_v3(
    level: int = logging.INFO,
    logger_name: str = "dic2d.v3",
    log_file: Optional[str | Path] = None,
) -> logging.Logger:
    """
    Crea o recupera un logger con formato homogéneo para DIC_2D_V3.

    Parameters
    ----------
    level : int
        Nivel de logging.
    logger_name : str
        Nombre base del logger.
    log_file : str | Path | None
        Archivo opcional para guardar el log.

    Returns
    -------
    logging.Logger
    """
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False

    # Evitar duplicación de handlers si se ejecuta varias veces en Spyder.
    if logger.handlers:
        for h in logger.handlers:
            h.setLevel(level)
        return logger

    fmt = logging.Formatter(
        fmt="[%(asctime)s] %(levelname)-7s %(name)s — %(message)s",
        datefmt="%H:%M:%S",
    )

    sh = logging.StreamHandler()
    sh.setLevel(level)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    if log_file is not None:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger


# =====================================================================
# Timer
# =====================================================================
class Timer(ContextDecorator):
    """
    Cronómetro simple para medir bloques de código.

    Ejemplo
    -------
    with Timer("Carga de imágenes", logger):
        ...
    """

    def __init__(
        self,
        label: str,
        logger: Optional[logging.Logger] = None,
        level: int = logging.INFO,
        use_perf_counter: bool = True,
    ) -> None:
        self.label = str(label)
        self.logger = logger
        self.level = level
        self.use_perf_counter = use_perf_counter
        self.t0: Optional[float] = None
        self.elapsed_s: Optional[float] = None

    def _now(self) -> float:
        return time.perf_counter() if self.use_perf_counter else time.time()

    def __enter__(self) -> "Timer":
        self.t0 = self._now()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self.t0 is None:
            return False

        self.elapsed_s = self._now() - self.t0

        if self.logger is not None:
            self.logger.log(self.level, f"{self.label}: {self.elapsed_s:.3f} s")

        # Nunca suprimir excepciones.
        return False


# =====================================================================
# Helpers de rutas / archivos
# =====================================================================
def ensure_dir(path: str | Path) -> Path:
    """Crea un directorio si no existe y devuelve Path."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def list_image_files(image_dir: str | Path, pattern: str) -> list[Path]:
    """
    Lista archivos de imagen ordenados alfabéticamente.
    """
    root = Path(image_dir)
    files = sorted(root.glob(pattern))
    return [f for f in files if f.is_file()]


# =====================================================================
# Helpers numéricos ligeros
# =====================================================================
def as_float_array(x: Any, copy: bool = False) -> np.ndarray:
    """Convierte a ndarray float64."""
    return np.array(x, dtype=float, copy=copy)


def finite_mask(*arrays: Iterable[Any]) -> np.ndarray:
    """
    Máscara conjunta de finitud para varios arreglos broadcastables.
    """
    arrays = [np.asarray(a) for a in arrays]
    if len(arrays) == 0:
        raise ValueError("finite_mask requiere al menos un arreglo.")

    mask = np.isfinite(arrays[0])
    for a in arrays[1:]:
        mask &= np.isfinite(a)
    return mask


def nanrms(x: Any) -> float:
    """RMS ignorando NaN."""
    arr = np.asarray(x, dtype=float)
    m = np.isfinite(arr)
    if not np.any(m):
        return float("nan")
    return float(np.sqrt(np.mean(arr[m] ** 2)))


def nanrange(x: Any) -> tuple[float, float]:
    """Rango min/max ignorando NaN."""
    arr = np.asarray(x, dtype=float)
    m = np.isfinite(arr)
    if not np.any(m):
        return float("nan"), float("nan")
    return float(np.nanmin(arr)), float(np.nanmax(arr))


def robust_limits(
    x: Any,
    p_low: float = 2.0,
    p_high: float = 98.0,
    symmetric: bool = False,
    center: float = 0.0,
) -> tuple[float, float]:
    """
    Límites robustos por percentiles para visualización.
    """
    arr = np.asarray(x, dtype=float).ravel()
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return -1.0, 1.0

    vmin, vmax = np.nanpercentile(arr, [p_low, p_high])

    if symmetric:
        a = max(abs(vmin - center), abs(vmax - center))
        vmin = center - a
        vmax = center + a

    if math.isclose(vmin, vmax):
        pad = 1e-12 if vmax == 0 else 0.05 * abs(vmax)
        vmin -= pad
        vmax += pad

    return float(vmin), float(vmax)


def clip_percentile(x: Any, p_low: float = 2.0, p_high: float = 98.0) -> np.ndarray:
    """
    Recorte por percentiles preservando NaN.
    """
    arr = np.asarray(x, dtype=float).copy()
    m = np.isfinite(arr)
    if not np.any(m):
        return arr

    lo, hi = np.nanpercentile(arr[m], [p_low, p_high])
    arr[m] = np.clip(arr[m], lo, hi)
    return arr


def to_microstrain(x: Any) -> np.ndarray:
    """Convierte strain adimensional a microstrain."""
    return 1e6 * np.asarray(x, dtype=float)


# =====================================================================
# GPU helpers ligeros
# =====================================================================
def torch_cuda_info() -> dict[str, Any]:
    """
    Información mínima de CUDA vía PyTorch.
    No fuerza dependencia dura si torch no está instalado.
    """
    info = {
        "torch_available": False,
        "cuda_available": False,
        "device": "cpu",
        "device_name": "CPU",
    }

    try:
        import torch

        info["torch_available"] = True
        info["cuda_available"] = bool(torch.cuda.is_available())

        if info["cuda_available"]:
            info["device"] = "cuda:0"
            info["device_name"] = torch.cuda.get_device_name(0)
        return info
    except Exception:
        return info


__all__ = [
    "Timer",
    "setup_logging_v3",
    "ensure_dir",
    "list_image_files",
    "as_float_array",
    "finite_mask",
    "nanrms",
    "nanrange",
    "robust_limits",
    "clip_percentile",
    "to_microstrain",
    "torch_cuda_info",
]
