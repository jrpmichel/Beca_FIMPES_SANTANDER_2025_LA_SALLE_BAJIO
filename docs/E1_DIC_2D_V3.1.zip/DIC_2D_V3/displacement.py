# -*- coding: utf-8 -*-
"""
DIC_2D_V3/displacement.py

Postproceso de desplazamientos para DIC_2D_V3.

Cambios V3.1
-------------
- disp_mag = |d| = sqrt(u² + v²) calculado y almacenado explícitamente.
- Conversión a mm robusta con disp_mag_mm.
- Resumen visual con auto-escalado y unidades correctas.
"""

from __future__ import annotations

import logging
from typing import Optional, Tuple

import numpy as np
from scipy.interpolate import griddata
from scipy.ndimage import gaussian_filter, median_filter

from .project import DICProjectV3
from .utils import Timer, nanrange

logger = logging.getLogger("dic2d.v3.displacement")


def _require_regular_grid(project: DICProjectV3) -> Tuple[int, int]:
    if project.grid_shape is None:
        raise ValueError("run_displacement_v3 requiere una grilla regular.")
    ny, nx = project.grid_shape
    return int(ny), int(nx)


def _reshape_field(z, ny, nx):
    return np.asarray(z, dtype=float).reshape(ny, nx)


def _flatten_field(Z):
    return np.asarray(Z, dtype=float).reshape(-1)


def _get_mm_per_px(project: DICProjectV3) -> Optional[float]:
    cal = getattr(project, "calibration", None)
    if cal is None:
        return None
    val = getattr(cal, "mm_per_px", None)
    if val is None:
        return None
    try:
        val = float(val)
        if np.isfinite(val) and val > 0:
            return val
    except Exception:
        pass
    return None


def _local_median_outliers(U, V, valid, threshold, footprint=3):
    U = np.asarray(U, dtype=float)
    V = np.asarray(V, dtype=float)
    valid = np.asarray(valid, dtype=bool)
    if not np.any(valid):
        return np.zeros_like(valid, dtype=bool)

    u_med = np.nanmedian(U[valid])
    v_med = np.nanmedian(V[valid])
    U_fill = np.where(valid, U, u_med)
    V_fill = np.where(valid, V, v_med)

    med_u = median_filter(U_fill, size=footprint, mode="nearest")
    med_v = median_filter(V_fill, size=footprint, mode="nearest")
    rmag = np.hypot(U - med_u, V - med_v)

    rmag_fill = np.where(valid, rmag, np.nanmedian(rmag[valid]))
    mad = median_filter(rmag_fill, size=footprint, mode="nearest")
    mad = np.where(mad < 1e-12, 1e-12, mad)

    out = np.zeros_like(valid, dtype=bool)
    out[valid] = rmag[valid] > (threshold * mad[valid])
    return out


def _fill_missing_regular_grid(Z, gx2d, gy2d, method="griddata"):
    Z = np.asarray(Z, dtype=float)
    mask = np.isfinite(Z)
    n_valid = int(np.count_nonzero(mask))
    if n_valid == Z.size or n_valid == 0:
        return Z.copy()

    pts = np.column_stack([gx2d[mask], gy2d[mask]])
    vals = Z[mask]
    q = np.column_stack([gx2d.ravel(), gy2d.ravel()])

    if n_valid < 4:
        Zn = griddata(pts, vals, q, method="nearest", fill_value=np.nan).reshape(Z.shape)
        Zi = Z.copy()
        Zi[~mask] = Zn[~mask]
        return Zi

    interp_method = "linear" if str(method).lower().strip() == "griddata" else str(method).lower().strip()
    try:
        Zi = griddata(pts, vals, q, method=interp_method, fill_value=np.nan).reshape(Z.shape)
    except Exception:
        Zi = np.full_like(Z, np.nan, dtype=float)

    if np.any(~np.isfinite(Zi)):
        Zn = griddata(pts, vals, q, method="nearest", fill_value=np.nan).reshape(Z.shape)
        Zi[~np.isfinite(Zi)] = Zn[~np.isfinite(Zi)]
    return Zi


def _smooth_field(Z, method, kernel):
    Z = np.asarray(Z, dtype=float)
    if method is None:
        return Z.copy()
    method = str(method).lower().strip()
    if method == "none" or kernel < 1:
        return Z.copy()
    if method == "gaussian":
        return gaussian_filter(Z, sigma=max(kernel / 3.0, 0.5), mode="nearest")
    if method == "median":
        k = kernel if kernel % 2 == 1 else kernel + 1
        return median_filter(Z, size=k, mode="nearest")
    return Z.copy()


def _show_displacement_summary(project: DICProjectV3) -> None:
    try:
        import matplotlib.pyplot as plt

        if project.disp_x is None or project.disp_y is None:
            return

        gx = np.asarray(project.grid_x, dtype=float)
        gy = np.asarray(project.grid_y, dtype=float)
        last = project.disp_x.shape[1] - 1

        unit = str(project.displacement_meta.get("unit_used", "px"))
        mm_per_px = _get_mm_per_px(project)
        if unit == "mm" and mm_per_px is not None:
            gx_d = gx * mm_per_px
            gy_d = gy * mm_per_px
        else:
            gx_d = gx
            gy_d = gy

        ux = project.disp_x[:, last]
        uy = project.disp_y[:, last]
        mag = project.disp_mag[:, last] if project.disp_mag is not None else np.hypot(ux, uy)

        fig, axes = plt.subplots(1, 3, figsize=(16, 5))
        fig.suptitle(f"Desplazamientos V3 — frame {last+1}", fontsize=12)

        for ax, data, ttl, cmap, sym in zip(
            axes,
            [ux, uy, mag],
            [f"U [{unit}]", f"V [{unit}]", f"|d| [{unit}]"],
            ["coolwarm", "coolwarm", "hot"],
            [True, True, False],
        ):
            mask = np.isfinite(data)
            if np.count_nonzero(mask) == 0:
                ax.set_title(f"{ttl} — sin datos")
                continue
            vmin = float(np.nanpercentile(data[mask], 1))
            vmax = float(np.nanpercentile(data[mask], 99))
            if sym:
                a = max(abs(vmin), abs(vmax))
                vmin, vmax = -a, a
            if abs(vmax - vmin) < 1e-12:
                vmin -= 1e-6
                vmax += 1e-6
            sc = ax.scatter(gx_d[mask], gy_d[mask], c=data[mask],
                            cmap=cmap, s=10, edgecolors="none",
                            vmin=vmin, vmax=vmax)
            cb = fig.colorbar(sc, ax=ax, shrink=0.75)
            cb.set_label(unit)
            ax.set_title(ttl)
            ax.set_aspect("equal")
            ax.invert_yaxis()
            ax.axis("off")

        plt.tight_layout()
        plt.show(block=False)
        plt.pause(0.5)
    except Exception as exc:
        logger.warning("No se pudo mostrar resumen de desplazamientos: %s", exc)


def run_displacement_v3(project: DICProjectV3, show_summary: bool = True) -> DICProjectV3:
    if not project.is_ready_for("displacement_done"):
        raise RuntimeError("Primero debe completar la correlación (correlation_done).")
    if project.corr_u is None or project.corr_v is None:
        raise ValueError("No existen corr_u/corr_v en el proyecto.")

    ny, nx = _require_regular_grid(project)
    n_points = int(project.num_points)
    n_frames = int(project.corr_u.shape[1])
    cfg = project.config
    dcfg = cfg.displacement

    gx = np.asarray(project.grid_x, dtype=float).ravel()
    gy = np.asarray(project.grid_y, dtype=float).ravel()
    gx2d = gx.reshape(ny, nx)
    gy2d = gy.reshape(ny, nx)

    disp_x_px = np.full((n_points, n_frames), np.nan, dtype=float)
    disp_y_px = np.full((n_points, n_frames), np.nan, dtype=float)
    outliers_corr_total = 0
    outliers_median_total = 0
    filled_total = 0
    corrcoef_min = float(cfg.dic.corrcoef_min)

    with Timer("Desplazamientos V3", logger):
        for k in range(n_frames):
            U = _reshape_field(project.corr_u[:, k], ny, nx)
            V = _reshape_field(project.corr_v[:, k], ny, nx)
            CC = _reshape_field(project.corr_coeff[:, k], ny, nx)
            FL = _reshape_field(project.corr_flags[:, k], ny, nx)

            valid = np.isfinite(U) & np.isfinite(V)
            bad_corr = (~np.isfinite(CC)) | (CC < corrcoef_min) | (FL < 1)
            outliers_corr_total += int(np.count_nonzero(bad_corr & valid))
            valid &= ~bad_corr

            if "median" in str(dcfg.outlier_method).lower() and np.any(valid):
                bad_med = _local_median_outliers(U, V, valid, float(dcfg.median_threshold), 3)
                outliers_median_total += int(np.count_nonzero(bad_med & valid))
                valid &= ~bad_med

            Uc = np.where(valid, U, np.nan)
            Vc = np.where(valid, V, np.nan)

            n_valid_frame = int(np.count_nonzero(np.isfinite(Uc) & np.isfinite(Vc)))
            if bool(dcfg.fill_missing):
                if n_valid_frame < 4:
                    logger.warning("Frame %d: solo %d válidos. Se omite fill.", k+1, n_valid_frame)
                else:
                    n_before = int(np.count_nonzero(~np.isfinite(Uc) | ~np.isfinite(Vc)))
                    Uc = _fill_missing_regular_grid(Uc, gx2d, gy2d, method=str(dcfg.fill_method))
                    Vc = _fill_missing_regular_grid(Vc, gx2d, gy2d, method=str(dcfg.fill_method))
                    n_after = int(np.count_nonzero(~np.isfinite(Uc) | ~np.isfinite(Vc)))
                    filled_total += max(0, n_before - n_after)

            Uc = _smooth_field(Uc, method=str(dcfg.spatial_smoothing), kernel=int(dcfg.smoothing_kernel))
            Vc = _smooth_field(Vc, method=str(dcfg.spatial_smoothing), kernel=int(dcfg.smoothing_kernel))

            disp_x_px[:, k] = _flatten_field(Uc)
            disp_y_px[:, k] = _flatten_field(Vc)

    project.disp_x_px = disp_x_px
    project.disp_y_px = disp_y_px
    disp_mag_px = np.hypot(disp_x_px, disp_y_px)

    mm_per_px = _get_mm_per_px(project)
    if mm_per_px is not None:
        project.disp_x_mm = disp_x_px * mm_per_px
        project.disp_y_mm = disp_y_px * mm_per_px
        project.disp_mag_mm = disp_mag_px * mm_per_px
    else:
        project.disp_x_mm = None
        project.disp_y_mm = None
        project.disp_mag_mm = None

    output_units = str(cfg.imaging.output_units).lower().strip()
    if output_units == "mm" and project.disp_x_mm is not None:
        project.disp_x = project.disp_x_mm
        project.disp_y = project.disp_y_mm
        project.disp_mag = project.disp_mag_mm
        unit_used = "mm"
    else:
        project.disp_x = project.disp_x_px
        project.disp_y = project.disp_y_px
        project.disp_mag = disp_mag_px
        unit_used = "px"

    project.displacement_meta = {
        "outlier_method": dcfg.outlier_method,
        "median_threshold": float(dcfg.median_threshold),
        "corrcoef_min": corrcoef_min,
        "spatial_smoothing": str(dcfg.spatial_smoothing),
        "smoothing_kernel": int(dcfg.smoothing_kernel),
        "fill_missing": bool(dcfg.fill_missing),
        "fill_method": str(dcfg.fill_method),
        "outliers_corr_total": int(outliers_corr_total),
        "outliers_median_total": int(outliers_median_total),
        "filled_total": int(filled_total),
        "unit_used": unit_used,
        "mm_per_px": mm_per_px,
        "grid_shape": tuple(project.grid_shape) if project.grid_shape is not None else None,
    }

    rx = nanrange(project.disp_x)
    ry = nanrange(project.disp_y)
    rd = nanrange(project.disp_mag)
    logger.info(
        "Desplazamientos V3: %d pts x %d frames [%s] | u=[%.6f,%.6f] | v=[%.6f,%.6f] | |d|=[%.6f,%.6f]",
        n_points, n_frames, unit_used, rx[0], rx[1], ry[0], ry[1], rd[0], rd[1]
    )
    logger.info("Outliers corr: %d | median: %d | filled: %d",
                outliers_corr_total, outliers_median_total, filled_total)

    project.mark_step("displacement_done")
    if show_summary:
        _show_displacement_summary(project)
    return project


__all__ = ["run_displacement_v3"]
