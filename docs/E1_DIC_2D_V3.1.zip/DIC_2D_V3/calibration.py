# -*- coding: utf-8 -*-
"""
DIC_2D_V3/calibration.py

Calibración y metrología básica para DIC_2D_V3.

Responsabilidades:
- cargar una calibración guardada si existe;
- permitir una calibración interactiva simple de escala mm/px;
- aplicar corrección de distorsión si se dispone de camera_matrix + dist_coeffs;
- persistir la calibración para reutilización.

Notas:
- En esta primera versión V3 se implementa la parte crítica para metrología DIC 2D:
  la relación mm/px.
- Si las imágenes ya fueron corregidas externamente por calibración, esta etapa puede
  limitarse a cargar/medir mm_per_px y NO volver a undistorsionar.
- La calibración intrínseca completa con chessboard puede incorporarse después sin romper
  la interfaz pública definida aquí.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict
from pathlib import Path
from typing import Optional, Tuple

import cv2
import numpy as np

from .project import CalibrationDataV3, DICProjectV3
from .utils import Timer, ensure_dir

logger = logging.getLogger("dic2d.v3.calibration")


# =====================================================================
# Helpers de persistencia
# =====================================================================
def _calibration_stem(project: DICProjectV3) -> str:
    return f"{project.project_name}_calibration_v3"


def _candidate_calibration_paths(project: DICProjectV3) -> list[Path]:
    out_dir = ensure_dir(project.output_dir)
    img_dir = Path(project.config.image_dir)
    if not img_dir.is_absolute():
        img_dir = Path.cwd() / img_dir

    stem = _calibration_stem(project)
    candidates = [
        out_dir / f"{stem}.npz",
        out_dir / f"{stem}.json",
        img_dir / f"{stem}.npz",
        img_dir / f"{stem}.json",
        out_dir / "calibration_v3.npz",
        out_dir / "calibration_v3.json",
        img_dir / "calibration_v3.npz",
        img_dir / "calibration_v3.json",
    ]
    # preservar orden y eliminar duplicados
    seen = set()
    unique = []
    for p in candidates:
        key = str(p.resolve()) if p.exists() else str(p)
        if key not in seen:
            unique.append(p)
            seen.add(key)
    return unique


def _load_calibration_file(path: Path) -> CalibrationDataV3:
    if path.suffix.lower() == ".npz":
        data = np.load(path, allow_pickle=True)
        cal = CalibrationDataV3()
        if "mm_per_px" in data:
            val = data["mm_per_px"]
            cal.mm_per_px = float(np.asarray(val).ravel()[0])
        if "reprojection_error_px" in data:
            cal.reprojection_error_px = float(np.asarray(data["reprojection_error_px"]).ravel()[0])
        if "stereo_rms_px" in data:
            cal.stereo_rms_px = float(np.asarray(data["stereo_rms_px"]).ravel()[0])
        if "camera_matrix" in data:
            cal.camera_matrix = np.asarray(data["camera_matrix"], dtype=float)
        if "dist_coeffs" in data:
            cal.dist_coeffs = np.asarray(data["dist_coeffs"], dtype=float)
        cal.extra["source_file"] = str(path)
        cal.extra["format"] = "npz"
        return cal

    if path.suffix.lower() == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        cal = CalibrationDataV3()
        if payload.get("mm_per_px") is not None:
            cal.mm_per_px = float(payload["mm_per_px"])
        if payload.get("reprojection_error_px") is not None:
            cal.reprojection_error_px = float(payload["reprojection_error_px"])
        if payload.get("stereo_rms_px") is not None:
            cal.stereo_rms_px = float(payload["stereo_rms_px"])
        if payload.get("camera_matrix") is not None:
            cal.camera_matrix = np.asarray(payload["camera_matrix"], dtype=float)
        if payload.get("dist_coeffs") is not None:
            cal.dist_coeffs = np.asarray(payload["dist_coeffs"], dtype=float)
        cal.extra["source_file"] = str(path)
        cal.extra["format"] = "json"
        return cal

    raise ValueError(f"Formato de calibración no soportado: {path}")


def _save_calibration_file(project: DICProjectV3) -> tuple[Path, Path]:
    out_dir = ensure_dir(project.output_dir)
    stem = _calibration_stem(project)
    npz_path = out_dir / f"{stem}.npz"
    json_path = out_dir / f"{stem}.json"

    cal = project.calibration

    np.savez_compressed(
        npz_path,
        mm_per_px=np.nan if cal.mm_per_px is None else float(cal.mm_per_px),
        reprojection_error_px=np.nan if cal.reprojection_error_px is None else float(cal.reprojection_error_px),
        stereo_rms_px=np.nan if cal.stereo_rms_px is None else float(cal.stereo_rms_px),
        camera_matrix=np.array([]) if cal.camera_matrix is None else np.asarray(cal.camera_matrix, dtype=float),
        dist_coeffs=np.array([]) if cal.dist_coeffs is None else np.asarray(cal.dist_coeffs, dtype=float),
    )

    payload = {
        "mm_per_px": None if cal.mm_per_px is None else float(cal.mm_per_px),
        "reprojection_error_px": None if cal.reprojection_error_px is None else float(cal.reprojection_error_px),
        "stereo_rms_px": None if cal.stereo_rms_px is None else float(cal.stereo_rms_px),
        "camera_matrix": None if cal.camera_matrix is None else np.asarray(cal.camera_matrix, dtype=float).tolist(),
        "dist_coeffs": None if cal.dist_coeffs is None else np.asarray(cal.dist_coeffs, dtype=float).tolist(),
        "extra": dict(cal.extra),
    }
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return npz_path, json_path


# =====================================================================
# Helpers numéricos
# =====================================================================
def _has_intrinsics(cal: CalibrationDataV3) -> bool:
    return (
        cal.camera_matrix is not None
        and cal.dist_coeffs is not None
        and np.size(cal.camera_matrix) >= 9
        and np.size(cal.dist_coeffs) >= 1
    )


def _apply_undistortion(project: DICProjectV3) -> bool:
    cal = project.calibration
    if not _has_intrinsics(cal):
        return False
    if project.images is None or len(project.images) == 0:
        return False

    K = np.asarray(cal.camera_matrix, dtype=float)
    d = np.asarray(cal.dist_coeffs, dtype=float).ravel()

    out = []
    for img in project.images:
        img32 = np.asarray(img, dtype=np.float32)
        und = cv2.undistort(img32, K, d)
        out.append(und.astype(np.float32, copy=False))
    project.images = out
    project.update_image_metadata()
    project.extra["undistortion_applied"] = True
    return True


def _interactive_measure_mm_per_px(project: DICProjectV3) -> float:
    if project.images is None or len(project.images) == 0:
        raise RuntimeError("No hay imágenes cargadas para calibración interactiva.")

    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        raise RuntimeError("matplotlib es necesario para calibración interactiva.") from exc

    img = np.asarray(project.images[project.reference_index], dtype=float)

    print("\n=== Calibración de escala DIC_2D_V3 ===")
    print("Seleccione DOS puntos que correspondan a una distancia conocida.")
    print("Después, introduzca la distancia real en mm en la consola.")

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.imshow(img, cmap="gray")
    ax.set_title("Seleccione 2 puntos para calibrar mm/px")
    ax.axis("on")

    pts = plt.ginput(2, timeout=0)
    plt.close(fig)

    if len(pts) != 2:
        raise RuntimeError("Se requieren exactamente 2 puntos para calibrar mm/px.")

    (x1, y1), (x2, y2) = pts
    dist_px = float(np.hypot(x2 - x1, y2 - y1))
    if dist_px <= 0:
        raise RuntimeError("La distancia en píxeles debe ser mayor que cero.")

    prompt = "Distancia real entre los dos puntos [mm]: "
    dist_mm = float(input(prompt).strip())
    if dist_mm <= 0:
        raise RuntimeError("La distancia real debe ser mayor que cero.")

    mm_per_px = dist_mm / dist_px
    logger.info(
        "Calibración interactiva: dist_px=%.6f px | dist_mm=%.6f mm | mm/px=%.9f",
        dist_px, dist_mm, mm_per_px,
    )
    return float(mm_per_px)


# =====================================================================
# API pública
# =====================================================================
def run_calibration_v3(
    project: DICProjectV3,
    interactive: bool = True,
    use_saved: bool = True,
) -> DICProjectV3:
    """
    Paso 2 del pipeline V3: metrología básica y calibración.

    Flujo:
    1) intenta cargar una calibración guardada si use_saved=True;
    2) si no existe y interactive=True, solicita medir mm/px sobre la imagen de referencia;
    3) si hay intrínsecos disponibles y distortion_correction=True, aplica undistortion.

    Parameters
    ----------
    project : DICProjectV3
        Proyecto con imágenes cargadas.
    interactive : bool
        Si es True, permite calibración interactiva de escala.
    use_saved : bool
        Si es True, intenta reutilizar una calibración guardada.

    Returns
    -------
    DICProjectV3
        Proyecto actualizado con calibración.
    """
    if not project.is_ready_for("calibration_done"):
        raise RuntimeError("Primero deben cargarse las imágenes (paso 1).")

    cfg = project.config.imaging

    with Timer("Calibración V3", logger):
        loaded_from: Optional[Path] = None

        # 1) Cargar calibración guardada
        if use_saved:
            for path in _candidate_calibration_paths(project):
                if path.exists():
                    try:
                        project.calibration = _load_calibration_file(path)
                        loaded_from = path
                        logger.info("Calibración cargada desde: %s", path)
                        break
                    except Exception as exc:
                        logger.warning("No fue posible cargar calibración desde %s: %s", path, exc)

        # 2) Si no se pudo cargar, conservar mm_per_px existente o pedirlo interactivo
        if project.calibration.mm_per_px is None:
            if interactive:
                mm_per_px = _interactive_measure_mm_per_px(project)
                project.calibration.mm_per_px = mm_per_px
                project.calibration.extra["source"] = "interactive_scale"
            else:
                # Si no se requiere salida métrica, permitir continuar sin mm/px.
                if cfg.output_units == "mm" or project.config.displacement.export_displacements_in_mm:
                    raise ValueError(
                        "No existe calibración guardada y se requiere salida métrica. "
                        "Active interactive=True o proporcione un archivo de calibración." 
                    )

        # 3) Aplicar undistortion si procede
        if cfg.distortion_correction and _has_intrinsics(project.calibration):
            applied = _apply_undistortion(project)
            logger.info("Corrección de distorsión aplicada: %s", applied)
        else:
            # No forzar error: muchas veces las imágenes ya llegan corregidas.
            project.extra.setdefault("undistortion_applied", False)

        # 4) Guardar calibración reutilizable
        npz_path, json_path = _save_calibration_file(project)
        logger.info("Calibración guardada en: %s", npz_path)
        logger.info("Calibración guardada en: %s", json_path)

        if loaded_from is not None:
            project.calibration.extra["loaded_from"] = str(loaded_from)

        if project.calibration.mm_per_px is not None:
            project.extra["mm_per_px"] = float(project.calibration.mm_per_px)

    project.mark_step("calibration_done")
    return project


__all__ = [
    "run_calibration_v3",
]
