# -*- coding: utf-8 -*-
"""
DIC_2D_V3/image_loader.py

Carga ordenada de imágenes para el pipeline DIC_2D_V3.

Responsabilidades:
- localizar archivos según image_dir + image_pattern;
- leer imágenes en escala de grises;
- normalizar a float32;
- almacenar imágenes y metadatos dentro de DICProjectV3;
- ofrecer una vista previa ligera.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List

import cv2
import numpy as np

from .project import DICProjectV3
from .utils import Timer, list_image_files

logger = logging.getLogger("dic2d.v3.image_loader")


# =====================================================================
# Helpers internos
# =====================================================================
def _read_image_gray_float32(path: str | Path) -> np.ndarray:
    """
    Lee una imagen y la devuelve como float32 en escala de grises.

    Regla de normalización:
    - si el rango parece entero de 8/16 bits, se normaliza a [0, 1];
    - si ya es flotante razonable, se conserva en float32.
    """
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError(f"No se pudo leer la imagen: {path}")

    if img.ndim == 3:
        if img.shape[2] == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        elif img.shape[2] == 4:
            img = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
        else:
            img = img[..., 0]

    img = np.asarray(img)

    if np.issubdtype(img.dtype, np.integer):
        info = np.iinfo(img.dtype)
        denom = float(max(info.max, 1))
        img = img.astype(np.float32) / denom
    else:
        img = img.astype(np.float32, copy=False)
        vmax = float(np.nanmax(img)) if img.size else 0.0
        vmin = float(np.nanmin(img)) if img.size else 0.0
        # Si parece venir en 0..255 o similar, se normaliza.
        if vmax > 1.5 and vmin >= 0.0:
            img = img / vmax

    return img


def _validate_stack(images: List[np.ndarray]) -> tuple[int, int]:
    """Verifica compatibilidad de shape y devuelve (h, w)."""
    if len(images) < 2:
        raise ValueError("Se requieren al menos dos imágenes para DIC 2D.")

    shape0 = tuple(images[0].shape)
    if len(shape0) != 2:
        raise ValueError("Las imágenes deben ser 2D en escala de grises.")

    for i, img in enumerate(images[1:], start=1):
        if tuple(img.shape) != shape0:
            raise ValueError(
                f"Todas las imágenes deben tener la misma resolución. "
                f"La imagen 0 tiene shape={shape0} y la imagen {i} tiene shape={tuple(img.shape)}."
            )
    return shape0


def _show_preview(images: List[np.ndarray], file_list: List[Path], title: str = "Vista previa DIC V3") -> None:
    """Vista previa ligera: primera, media y última imagen."""
    try:
        import matplotlib.pyplot as plt

        n = len(images)
        idxs = [0, n // 2, n - 1] if n >= 3 else list(range(n))
        idxs = sorted(set(idxs))

        fig, axes = plt.subplots(1, len(idxs), figsize=(5 * len(idxs), 4))
        if len(idxs) == 1:
            axes = [axes]

        fig.suptitle(title, fontsize=12)
        for ax, idx in zip(axes, idxs):
            ax.imshow(images[idx], cmap="gray")
            ax.set_title(f"{idx}: {file_list[idx].name}", fontsize=9)
            ax.axis("off")

        plt.tight_layout()
        plt.show(block=False)
        plt.pause(0.5)
    except Exception as exc:
        logger.warning("No fue posible mostrar vista previa: %s", exc)


# =====================================================================
# API pública
# =====================================================================
def run_image_loader_v3(
    project: DICProjectV3,
    show_preview: bool = True,
) -> DICProjectV3:
    """
    Paso 1 del pipeline V3: cargar imágenes del ensayo.

    Parameters
    ----------
    project : DICProjectV3
        Proyecto con configuración ya creada.
    show_preview : bool
        Si es True, muestra una vista previa ligera.

    Returns
    -------
    DICProjectV3
        Proyecto actualizado con imágenes y metadatos.
    """
    cfg = project.config
    image_dir = Path(cfg.image_dir)
    image_pattern = str(cfg.image_pattern)

    if not image_dir.is_absolute():
        image_dir = Path.cwd() / image_dir

    if not image_dir.exists():
        raise FileNotFoundError(f"El directorio de imágenes no existe: {image_dir}")

    with Timer("Carga de imágenes", logger):
        file_list = list_image_files(image_dir, image_pattern)
        if len(file_list) < 2:
            raise ValueError(
                f"Se encontraron {len(file_list)} imágenes con el patrón '{image_pattern}' en '{image_dir}'. "
                "Se requieren al menos 2."
            )

        images = [_read_image_gray_float32(fp) for fp in file_list]
        shape_hw = _validate_stack(images)

    project.images = images
    project.image_files = [str(fp) for fp in file_list]
    project.reference_index = 0
    project.update_image_metadata()
    project.extra["image_dir_resolved"] = str(image_dir)
    project.extra["image_pattern"] = image_pattern
    project.extra["image_dtype"] = str(images[0].dtype)
    project.extra["image_range"] = (float(np.nanmin(images[0])), float(np.nanmax(images[0])))
    project.mark_step("images_loaded")

    logger.info(
        "Imágenes cargadas: %d | shape=%s | referencia=%d",
        project.num_images,
        shape_hw,
        project.reference_index,
    )

    if show_preview:
        _show_preview(images, file_list)

    return project


__all__ = [
    "run_image_loader_v3",
]
