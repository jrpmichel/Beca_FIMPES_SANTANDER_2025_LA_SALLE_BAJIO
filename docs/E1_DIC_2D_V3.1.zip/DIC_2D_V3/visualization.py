# -*- coding: utf-8 -*-
"""
DIC_2D_V3/visualization.py

Visualización mejorada para DIC_2D_V3 — estilo inspirado en NCorr.

Cambios V3.1
-------------
- Escala de color auto-ajustada por gráfica (percentiles robustos).
- Coordenadas y resultados SIEMPRE en mm cuando existe calibración.
- Imagen de referencia como overlay semitransparente en contornos.
- Colormap tipo ncorr (jet) para desplazamientos, RdBu_r para strain.
- |d| calculado desde project.disp_mag.
- Dashboard incluye |d| en mm.
- Unidades explícitas en colorbar y títulos.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence, Tuple

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from scipy.interpolate import NearestNDInterpolator, SmoothBivariateSpline

from .project import DICProjectV3
from .utils import clip_percentile, robust_limits

try:
    import torch
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except Exception:
    TORCH_AVAILABLE = False


# =====================================================================
# Helpers internos
# =====================================================================
def _resolve_device(device: str = "auto") -> str:
    if not TORCH_AVAILABLE:
        return "cpu"
    if device == "cpu":
        return "cpu"
    return "cuda:0" if torch.cuda.is_available() else "cpu"


def _get_mm_per_px(project: DICProjectV3):
    cal = getattr(project, "calibration", None)
    val = getattr(cal, "mm_per_px", None)
    try:
        val = float(val)
        if np.isfinite(val) and val > 0:
            return val
    except Exception:
        pass
    return None


def _unit_label(project: DICProjectV3) -> str:
    """Unidad de desplazamiento activa."""
    meta = getattr(project, "displacement_meta", {}) or {}
    return "mm" if str(meta.get("unit_used", "px")).lower() == "mm" else "px"


def _display_xy(project: DICProjectV3):
    """Coordenadas de grilla en unidades de salida."""
    x = np.asarray(project.grid_x, dtype=float).ravel()
    y = np.asarray(project.grid_y, dtype=float).ravel()
    dunit = _unit_label(project)
    mm = _get_mm_per_px(project)
    if dunit == "mm" and mm is not None:
        return x * mm, y * mm
    return x, y


def _strain_factor(project: DICProjectV3):
    mode = str(project.config.imaging.strain_display_units).lower().strip()
    if mode == "microstrain":
        return 1e6, "[µε]"
    return 1.0, "[-]"


def _valid_xyz(x, y, z):
    x = np.asarray(x, dtype=float).ravel()
    y = np.asarray(y, dtype=float).ravel()
    z = np.asarray(z, dtype=float).ravel()
    m = np.isfinite(x) & np.isfinite(y) & np.isfinite(z)
    return x[m], y[m], z[m]


def _infer_regular_grid(x, y, z):
    x, y, z = _valid_xyz(x, y, z)
    xu = np.unique(np.round(x, 10))
    yu = np.unique(np.round(y, 10))
    nx, ny = xu.size, yu.size
    if nx * ny != x.size:
        XI0, YI0 = np.meshgrid(xu, yu)
        nn = NearestNDInterpolator(np.column_stack([x, y]), z)
        return xu, yu, nn(XI0, YI0)
    ix = np.searchsorted(xu, np.round(x, 10))
    iy = np.searchsorted(yu, np.round(y, 10))
    Z = np.full((ny, nx), np.nan, dtype=float)
    Z[iy, ix] = z
    if np.any(~np.isfinite(Z)):
        XI0, YI0 = np.meshgrid(xu, yu)
        nn = NearestNDInterpolator(np.column_stack([x, y]), z)
        Z = nn(XI0, YI0)
    return xu, yu, Z


def _surface_bspline(x, y, z, nx=300, ny=300, s_factor=0.02, kx=3, ky=3):
    x, y, z = _valid_xyz(x, y, z)
    if x.size < max((kx+1)*(ky+1), 16):
        raise ValueError("Insuficientes puntos para B-spline.")
    z_var = np.nanvar(z)
    if not np.isfinite(z_var) or z_var <= 0:
        z_var = 1.0
    s = float(s_factor) * x.size * z_var
    spline = SmoothBivariateSpline(x, y, z, kx=kx, ky=ky, s=s)
    xi = np.linspace(np.min(x), np.max(x), int(nx))
    yi = np.linspace(np.min(y), np.max(y), int(ny))
    XI, YI = np.meshgrid(xi, yi)
    ZI = spline.ev(XI.ravel(), YI.ravel()).reshape(XI.shape)
    return XI, YI, ZI


def _surface_torch_bicubic(x, y, z, nx=300, ny=300, device="auto"):
    device = _resolve_device(device)
    xu, yu, Z = _infer_regular_grid(x, y, z)
    if not TORCH_AVAILABLE:
        device = "cpu"
    t = torch.from_numpy(Z.astype(np.float32))[None, None, :, :]
    t = t.to(device)
    out = F.interpolate(t, size=(int(ny), int(nx)), mode="bicubic", align_corners=True)
    ZI = out[0, 0].detach().cpu().numpy()
    xi = np.linspace(np.min(xu), np.max(xu), int(nx))
    yi = np.linspace(np.min(yu), np.max(yu), int(ny))
    XI, YI = np.meshgrid(xi, yi)
    return XI, YI, ZI


def _smooth_surface(x, y, z, smooth_method="bspline", spline_s=0.02,
                    upsample_nx=300, upsample_ny=300, device="auto"):
    method = str(smooth_method).lower().strip()
    if method == "bspline":
        return _surface_bspline(x, y, z, nx=upsample_nx, ny=upsample_ny, s_factor=spline_s)
    if method == "torch_bicubic":
        return _surface_torch_bicubic(x, y, z, nx=upsample_nx, ny=upsample_ny, device=device)
    raise ValueError("smooth_method: 'bspline' o 'torch_bicubic'.")


def _auto_clim(z, symmetric=False, p_low=2, p_high=98):
    """Auto-escalado robusto para colorbar."""
    zf = np.asarray(z, dtype=float).ravel()
    zf = zf[np.isfinite(zf)]
    if zf.size == 0:
        return -1.0, 1.0
    vmin = float(np.percentile(zf, p_low))
    vmax = float(np.percentile(zf, p_high))
    if symmetric:
        a = max(abs(vmin), abs(vmax))
        vmin, vmax = -a, a
    if abs(vmax - vmin) < 1e-15:
        pad = 1e-6 if vmax == 0 else 0.05 * abs(vmax)
        vmin -= pad
        vmax += pad
    return float(vmin), float(vmax)


def _draw_smooth_map(ax, x, y, z, title="", cmap="viridis",
                     smooth_method="bspline", spline_s=0.02,
                     upsample_nx=300, upsample_ny=300, device="auto",
                     levels=120, symmetric=False,
                     clip_pct=(2, 98), cb_label=""):
    """Dibuja mapa suavizado con auto-escalado de colorbar."""
    z_raw = np.asarray(z, dtype=float).ravel()

    # Clipping por percentiles
    lo, hi = clip_pct
    z_disp = clip_percentile(z_raw, p_low=lo, p_high=hi)
    vmin, vmax = _auto_clim(z_raw, symmetric=symmetric, p_low=lo, p_high=hi)

    XI, YI, ZI = _smooth_surface(x, y, z_disp, smooth_method=smooth_method,
                                 spline_s=spline_s, upsample_nx=upsample_nx,
                                 upsample_ny=upsample_ny, device=device)
    ZI = np.clip(ZI, vmin, vmax)
    level_values = np.linspace(vmin, vmax, max(16, int(levels)))

    h = ax.contourf(XI, YI, ZI, levels=level_values, cmap=cmap, extend="both")
    ax.set_title(title)
    ax.set_aspect("equal")
    ax.invert_yaxis()
    return h, vmin, vmax


def _get_reference_image(project, frame=0):
    try:
        if project.images is not None and len(project.images) > 0:
            idx = max(0, min(int(frame), len(project.images) - 1))
            return np.asarray(project.images[idx], dtype=float)
    except Exception:
        pass
    return None


def _overlay_ref_image(ax, project, x, y):
    """Overlay de imagen de referencia como fondo semitransparente."""
    img = _get_reference_image(project, frame=0)
    if img is not None:
        ax.imshow(img, cmap="gray", alpha=0.25,
                  extent=[np.min(x), np.max(x), np.max(y), np.min(y)])


def _save_fig(fig, save_path):
    if save_path is None:
        return
    save_path = Path(save_path)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=220, bbox_inches="tight")


def _series_from_components(project, comp, metric="mean"):
    comp = str(comp).lower().strip()
    mapping = {
        "exx": (project.strain_xx, "εxx"),
        "eyy": (project.strain_yy, "εyy"),
        "exy": (project.strain_xy, "εxy"),
        "e1": (project.strain_e1, "ε1"),
        "e2": (project.strain_e2, "ε2"),
    }
    field, label = mapping[comp]
    if field is None:
        raise ValueError(f"Campo '{comp}' no disponible.")
    arr = np.asarray(field, dtype=float)
    ops = {"mean": np.nanmean, "median": np.nanmedian, "max": np.nanmax,
           "min": np.nanmin, "maxabs": lambda a, **kw: np.nanmax(np.abs(a), **kw)}
    return ops[metric](arr, axis=0), label


def _dmax_series(project):
    if project.disp_mag is not None:
        dmax = np.nanmax(project.disp_mag, axis=0)
    else:
        dmax = np.nanmax(np.hypot(project.disp_x, project.disp_y), axis=0)
    return dmax, _unit_label(project)


# =====================================================================
# API pública
# =====================================================================
def plot_quiver_v3(project, frame=-1, skip=2, quiver_gain=6.0,
                   smooth_vectors=True, smooth_method="bspline",
                   spline_s=0.01, upsample_nx=180, upsample_ny=180,
                   device="auto", width=0.0025, save_path=None, show=True):
    x, y = _display_xy(project)
    u = np.asarray(project.disp_x[:, frame], dtype=float).ravel()
    v = np.asarray(project.disp_y[:, frame], dtype=float).ravel()
    dunit = _unit_label(project)

    fig, ax = plt.subplots(figsize=(7.2, 8.0))
    _overlay_ref_image(ax, project, x, y)

    if smooth_vectors:
        XI, YI, UI = _smooth_surface(x, y, u, smooth_method=smooth_method,
                                     spline_s=spline_s, upsample_nx=upsample_nx,
                                     upsample_ny=upsample_ny, device=device)
        _, _, VI = _smooth_surface(x, y, v, smooth_method=smooth_method,
                                   spline_s=spline_s, upsample_nx=upsample_nx,
                                   upsample_ny=upsample_ny, device=device)
        DI = np.hypot(UI, VI)
        xs = XI[::skip, ::skip]
        ys = YI[::skip, ::skip]
        us = UI[::skip, ::skip]
        vs = VI[::skip, ::skip]
        cs = DI[::skip, ::skip]
    else:
        m = np.isfinite(x) & np.isfinite(y) & np.isfinite(u) & np.isfinite(v)
        xs, ys = x[m][::skip], y[m][::skip]
        us, vs = u[m][::skip], v[m][::skip]
        cs = np.hypot(us, vs)

    # Auto-escalado
    vmin_c, vmax_c = _auto_clim(cs, symmetric=False)

    q = ax.quiver(xs, ys, quiver_gain*us, quiver_gain*vs, cs,
                  cmap="hot", angles="xy", scale_units="xy", scale=1.0,
                  pivot="mid", width=width, headwidth=4.5, headlength=6.0,
                  headaxislength=5.5,
                  norm=Normalize(vmin=vmin_c, vmax=vmax_c))
    cbar = fig.colorbar(q, ax=ax)
    cbar.set_label(f"|d| [{dunit}]")

    ax.set_title(f"Desplazamiento (quiver) — frame {frame}")
    ax.set_xlabel(f"x [{dunit}]")
    ax.set_ylabel(f"y [{dunit}]")
    ax.set_aspect("equal")
    ax.invert_yaxis()

    _save_fig(fig, save_path)
    if show:
        plt.show()
    return fig, ax


def plot_field_map_v3(project, field, frame, title="", cmap="coolwarm",
                      smooth_method="bspline", spline_s=0.02,
                      upsample_nx=320, upsample_ny=320, device="auto",
                      levels=140, robust=True, clip_percentiles=(2, 98),
                      symmetric=True, save_path=None, show=True):
    x, y = _display_xy(project)
    z = np.asarray(field[:, frame], dtype=float).ravel()
    dunit = _unit_label(project)

    # Detectar si es strain y aplicar factor
    sfac, ssuf = _strain_factor(project)
    is_strain = (field is project.strain_xx or field is project.strain_yy or
                 field is project.strain_xy or field is project.strain_e1 or
                 field is project.strain_e2)
    if is_strain:
        z = z * sfac
        if title and "[" not in title:
            title = f"{title} {ssuf}"
        cb_label = ssuf
    else:
        if title and "[" not in title:
            title = f"{title} [{dunit}]"
        cb_label = dunit

    fig, ax = plt.subplots(figsize=(6.4, 5.4))
    _overlay_ref_image(ax, project, x, y)

    h, vmin, vmax = _draw_smooth_map(
        ax, x, y, z, title=title, cmap=cmap,
        smooth_method=smooth_method, spline_s=spline_s,
        upsample_nx=upsample_nx, upsample_ny=upsample_ny,
        device=device, levels=levels, symmetric=symmetric,
        clip_pct=clip_percentiles, cb_label=cb_label)
    cb = fig.colorbar(h, ax=ax)
    cb.set_label(cb_label)
    ax.set_xlabel(f"x [{dunit}]")
    ax.set_ylabel(f"y [{dunit}]")

    _save_fig(fig, save_path)
    if show:
        plt.show()
    return fig, ax


def plot_dashboard_v3(project, frame=-1, smooth_method="bspline",
                      spline_s=0.02, upsample_nx=320, upsample_ny=320,
                      device="auto", levels=140, save_path=None, show=True):
    x, y = _display_xy(project)
    dunit = _unit_label(project)
    sfac, ssuf = _strain_factor(project)

    u = np.asarray(project.disp_x[:, frame], dtype=float).ravel()
    v = np.asarray(project.disp_y[:, frame], dtype=float).ravel()
    d = project.disp_mag[:, frame] if project.disp_mag is not None else np.hypot(u, v)
    d = np.asarray(d, dtype=float).ravel()
    exx = np.asarray(project.strain_xx[:, frame], dtype=float).ravel() * sfac
    eyy = np.asarray(project.strain_yy[:, frame], dtype=float).ravel() * sfac
    exy = (np.asarray(project.strain_xy[:, frame], dtype=float).ravel() * sfac
           if project.strain_xy is not None else np.full_like(exx, np.nan))

    fig, axes = plt.subplots(2, 3, figsize=(17, 10))
    fig.suptitle(f"DIC 2D V3 — {project.config.project_name} — Frame {frame}",
                 fontsize=14, fontweight="bold")

    # (z, title, cmap, symmetric, clip_pct, spline_s_local, cb_label)
    panels = [
        (u,   f"U [{dunit}]",            "coolwarm",  True,  (1, 99), 0.015, dunit),
        (v,   f"V [{dunit}]",            "coolwarm",  True,  (1, 99), 0.015, dunit),
        (d,   f"|d| [{dunit}]",          "hot",       False, (1, 99), 0.015, dunit),
        (exx, f"εxx {ssuf}".strip(),     "RdBu_r",   True,  (2, 98), 0.008, ssuf),
        (eyy, f"εyy {ssuf}".strip(),     "RdBu_r",   True,  (2, 98), 0.008, ssuf),
        (exy, f"εxy {ssuf}".strip(),     "PuOr",     True,  (2, 98), 0.008, ssuf),
    ]

    for ax, (z, ttl, cmap, sym, cpct, ls, cbl) in zip(axes.flat, panels):
        _overlay_ref_image(ax, project, x, y)
        h, _, _ = _draw_smooth_map(
            ax, x, y, z, title=ttl, cmap=cmap,
            smooth_method=smooth_method, spline_s=ls,
            upsample_nx=upsample_nx, upsample_ny=upsample_ny,
            device=device, levels=levels, symmetric=sym, clip_pct=cpct)
        cb = fig.colorbar(h, ax=ax, shrink=0.82)
        cb.set_label(cbl, fontsize=8)
        ax.set_xlabel(f"x [{dunit}]", fontsize=8)
        ax.set_ylabel(f"y [{dunit}]", fontsize=8)

    plt.tight_layout()
    _save_fig(fig, save_path)
    if show:
        plt.show()
    return fig, axes


def plot_strain_vs_frame_v3(project, components=("exx", "eyy", "exy"),
                            metric="mean", save_path=None, show=True):
    sfac, ssuf = _strain_factor(project)
    fig, ax = plt.subplots(figsize=(8.2, 4.8))

    for comp in components:
        y_data, label = _series_from_components(project, comp, metric=metric)
        ax.plot(np.arange(y_data.size), y_data * sfac, linewidth=1.8, label=label)

    ax.set_xlabel("Frame")
    ax.set_ylabel(f"Strain {ssuf}".strip())
    ax.set_title(f"Strain vs frame ({metric})")
    ax.grid(True, alpha=0.3)
    ax.legend()
    _save_fig(fig, save_path)
    if show:
        plt.show()
    return fig, ax


def plot_strain_vs_max_displacement_v3(project, components=("exx", "eyy"),
                                       metric="mean", save_path=None, show=True):
    sfac, ssuf = _strain_factor(project)
    dmax, dunit = _dmax_series(project)

    fig, ax = plt.subplots(figsize=(7.8, 5.0))
    for comp in components:
        y_data, label = _series_from_components(project, comp, metric=metric)
        ax.plot(dmax, y_data * sfac, marker="o", linewidth=1.8,
                markersize=4, label=f"{label} ({metric})")

    ax.set_xlabel(f"|d|_max [{dunit}]")
    ax.set_ylabel(f"Strain {ssuf}".strip())
    ax.set_title("Strain vs desplazamiento máximo")
    ax.grid(True, alpha=0.3)
    ax.legend()
    _save_fig(fig, save_path)
    if show:
        plt.show()
    return fig, ax


__all__ = [
    "plot_dashboard_v3",
    "plot_quiver_v3",
    "plot_field_map_v3",
    "plot_strain_vs_frame_v3",
    "plot_strain_vs_max_displacement_v3",
]
