# -*- coding: utf-8 -*-
"""
DIC_2D_V3/project.py

Contenedor principal del pipeline DIC_2D_V3.

V3.1: Añade disp_mag, disp_mag_mm, u_combined.
"""

from __future__ import annotations

import pickle
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from .config import DICConfigV3


# =====================================================================
# Metadatos auxiliares
# =====================================================================
@dataclass
class CalibrationDataV3:
    mm_per_px: Optional[float] = None
    reprojection_error_px: Optional[float] = None
    stereo_rms_px: Optional[float] = None
    camera_matrix: Optional[np.ndarray] = None
    dist_coeffs: Optional[np.ndarray] = None
    rvecs: Optional[List[np.ndarray]] = None
    tvecs: Optional[List[np.ndarray]] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ROIDataV3:
    type: str = "rectangular"
    xmin: Optional[float] = None
    xmax: Optional[float] = None
    ymin: Optional[float] = None
    ymax: Optional[float] = None
    polygon: Optional[np.ndarray] = None


# =====================================================================
# Proyecto principal
# =====================================================================
class DICProjectV3:
    """
    Contenedor del estado completo del proyecto DIC.
    """

    STEP_ORDER = [
        "project_created",
        "images_loaded",
        "calibration_done",
        "grid_defined",
        "correlation_done",
        "displacement_done",
        "strain_done",
        "uncertainty_done",
        "saved",
    ]

    # -----------------------------------------------------------------
    # Construcción
    # -----------------------------------------------------------------
    def __init__(self, config: DICConfigV3):
        self.config = config

        # Información general
        self.project_name: str = config.project_name
        self.output_dir: str = config.output_dir
        self.created_from: str = "DIC_2D_V3"

        # Estado del pipeline
        self.completed_steps: List[str] = []
        self.logs: List[str] = []

        # Imágenes
        self.images: Optional[List[np.ndarray]] = None
        self.image_files: List[str] = []
        self.num_images: int = 0
        self.image_shape: Optional[tuple] = None
        self.reference_index: int = 0

        # Calibración
        self.calibration: CalibrationDataV3 = CalibrationDataV3()

        # ROI y grilla
        self.roi: ROIDataV3 = ROIDataV3(type=config.roi.type)
        self.grid_x: Optional[np.ndarray] = None
        self.grid_y: Optional[np.ndarray] = None
        self.grid_points: Optional[np.ndarray] = None
        self.num_points: int = 0
        self.grid_shape: Optional[tuple] = None  # (ny, nx)
        self.spacing_x: Optional[float] = None
        self.spacing_y: Optional[float] = None

        # Correlación
        self.corr_u: Optional[np.ndarray] = None
        self.corr_v: Optional[np.ndarray] = None
        self.corr_p: Optional[np.ndarray] = None
        self.corr_coeff: Optional[np.ndarray] = None
        self.corr_flags: Optional[np.ndarray] = None
        self.seed_points: Optional[np.ndarray] = None
        self.correlation_meta: Dict[str, Any] = {}

        # Desplazamiento / gradientes
        self.disp_x: Optional[np.ndarray] = None
        self.disp_y: Optional[np.ndarray] = None
        self.disp_mag: Optional[np.ndarray] = None       # |d| en unidades de salida
        self.disp_x_px: Optional[np.ndarray] = None
        self.disp_y_px: Optional[np.ndarray] = None
        self.disp_x_mm: Optional[np.ndarray] = None
        self.disp_y_mm: Optional[np.ndarray] = None
        self.disp_mag_mm: Optional[np.ndarray] = None     # |d| en mm
        self.invalid_mask: Optional[np.ndarray] = None
        self.outlier_mask: Optional[np.ndarray] = None
        self.displacement_meta: Dict[str, Any] = {}

        # Gradientes de desplazamiento
        self.du_dx: Optional[np.ndarray] = None
        self.du_dy: Optional[np.ndarray] = None
        self.dv_dx: Optional[np.ndarray] = None
        self.dv_dy: Optional[np.ndarray] = None

        # Strain
        self.strain_xx: Optional[np.ndarray] = None
        self.strain_yy: Optional[np.ndarray] = None
        self.strain_xy: Optional[np.ndarray] = None
        self.strain_e1: Optional[np.ndarray] = None
        self.strain_e2: Optional[np.ndarray] = None
        self.strain_theta: Optional[np.ndarray] = None
        self.strain_meta: Dict[str, Any] = {}

        # Incertidumbre
        self.ux: Optional[np.ndarray] = None
        self.uy: Optional[np.ndarray] = None
        self.u_combined: Optional[np.ndarray] = None      # u_d = sqrt(ux^2+uy^2)
        self.ustrain_xx: Optional[np.ndarray] = None
        self.ustrain_yy: Optional[np.ndarray] = None
        self.ustrain_xy: Optional[np.ndarray] = None
        self.uncertainty_meta: Dict[str, Any] = {}

        # Extras libres
        self.extra: Dict[str, Any] = {}

        self.mark_step("project_created")

    @classmethod
    def new(cls, config: DICConfigV3) -> "DICProjectV3":
        return cls(config)

    # -----------------------------------------------------------------
    # Estado / utilidades
    # -----------------------------------------------------------------
    def add_log(self, message: str) -> None:
        self.logs.append(str(message))

    def mark_step(self, step_name: str) -> None:
        if step_name not in self.completed_steps:
            self.completed_steps.append(step_name)

    def has_step(self, step_name: str) -> bool:
        return step_name in self.completed_steps

    def _required_previous_step(self, target_step: str) -> Optional[str]:
        requirements = {
            "images_loaded": "project_created",
            "calibration_done": "images_loaded",
            "grid_defined": "images_loaded",
            "correlation_done": "grid_defined",
            "displacement_done": "correlation_done",
            "strain_done": "displacement_done",
            "uncertainty_done": "strain_done",
            "saved": None,
        }
        return requirements.get(target_step, None)

    def is_ready_for(self, target_step: str) -> bool:
        required = self._required_previous_step(target_step)
        if required is None:
            return True
        return self.has_step(required)

    # -----------------------------------------------------------------
    # Metadatos derivados
    # -----------------------------------------------------------------
    def update_image_metadata(self) -> None:
        if self.images is None:
            self.num_images = 0
            self.image_shape = None
            return
        self.num_images = len(self.images)
        self.image_shape = tuple(np.asarray(self.images[0]).shape)

    def update_grid_metadata(self) -> None:
        if self.grid_x is None or self.grid_y is None:
            self.num_points = 0
            self.grid_points = None
            self.grid_shape = None
            return

        gx = np.asarray(self.grid_x).ravel()
        gy = np.asarray(self.grid_y).ravel()
        self.num_points = gx.size
        self.grid_points = np.column_stack([gx, gy])

        ux = np.unique(np.round(gx, 10))
        uy = np.unique(np.round(gy, 10))
        if ux.size * uy.size == gx.size:
            self.grid_shape = (uy.size, ux.size)
        else:
            self.grid_shape = None

    # -----------------------------------------------------------------
    # Guardado / carga
    # -----------------------------------------------------------------
    def save(self, filepath: Optional[str | Path] = None) -> Path:
        out_dir = Path(self.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        if filepath is None:
            filepath = out_dir / f"{self.project_name}.dicv3"
        else:
            filepath = Path(filepath)

        with open(filepath, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

        self.mark_step("saved")
        return filepath

    @classmethod
    def load(cls, filepath: str | Path) -> "DICProjectV3":
        filepath = Path(filepath)
        with open(filepath, "rb") as f:
            obj = pickle.load(f)

        if not isinstance(obj, cls):
            raise TypeError(f"El archivo no contiene un objeto {cls.__name__} válido.")
        return obj

    # -----------------------------------------------------------------
    # Resúmenes
    # -----------------------------------------------------------------
    def status_dict(self) -> Dict[str, Any]:
        return {
            "project_name": self.project_name,
            "output_dir": self.output_dir,
            "created_from": self.created_from,
            "completed_steps": list(self.completed_steps),
            "num_images": self.num_images,
            "image_shape": self.image_shape,
            "num_points": self.num_points,
            "grid_shape": self.grid_shape,
            "calibrated": self.calibration.mm_per_px is not None,
            "mm_per_px": self.calibration.mm_per_px,
            "has_correlation": self.corr_coeff is not None,
            "has_displacement": self.disp_x is not None and self.disp_y is not None,
            "has_strain": self.strain_xx is not None and self.strain_yy is not None,
            "has_uncertainty": self.ustrain_xx is not None or self.ux is not None,
        }

    def status_summary(self) -> str:
        s = self.status_dict()
        lines = [
            "DICProjectV3 status",
            f"  project_name   : {s['project_name']}",
            f"  output_dir     : {s['output_dir']}",
            f"  completed_steps: {', '.join(s['completed_steps'])}",
            f"  num_images     : {s['num_images']}",
            f"  image_shape    : {s['image_shape']}",
            f"  num_points     : {s['num_points']}",
            f"  grid_shape     : {s['grid_shape']}",
            f"  calibrated     : {s['calibrated']}",
            f"  mm_per_px      : {s['mm_per_px']}",
            f"  has_correlation: {s['has_correlation']}",
            f"  has_displacement: {s['has_displacement']}",
            f"  has_strain     : {s['has_strain']}",
            f"  has_uncertainty: {s['has_uncertainty']}",
        ]
        return "\n".join(lines)


__all__ = [
    "CalibrationDataV3",
    "ROIDataV3",
    "DICProjectV3",
]
